package com.react_java.reactjava.Tarearepository;

import com.react_java.reactjava.model.grado;
import com.react_java.reactjava.model.institucion;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface institucionRepository extends MongoRepository<institucion,String> {
    @Query("{ $and:[{nombre:?0},{departamento:?1},{municipio:?2},{zona:?3}]}")
    List<grado> findBygradoandgrupoandjornada(String nombre, String departamento, String municipio, String zona, String value);


}
