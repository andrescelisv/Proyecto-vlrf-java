package com.react_java.reactjava.model;

import com.react_java.reactjava.modelDTO.docentesDTO;
import com.react_java.reactjava.modelDTO.gradoDTO;
import com.react_java.reactjava.modelDTO.institucionDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@AllArgsConstructor
@Document(collection = "")
public class dba_RHU {



    private String dba;
    private String fecha;
    private List<docentesDTO> docente;
    private List<videovisto> videovisto;

    public List<com.react_java.reactjava.model.videovisto> getVideovisto() {
        return videovisto;
    }

    public void setVideovisto(List<com.react_java.reactjava.model.videovisto> videovisto) {
        this.videovisto = videovisto;
    }



    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public List<docentesDTO> getDocente() {
        return docente;
    }

    public void setDocente(List<docentesDTO> docente) {
        this.docente = docente;
    }













}
