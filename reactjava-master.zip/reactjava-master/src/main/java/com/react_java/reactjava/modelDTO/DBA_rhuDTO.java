package com.react_java.reactjava.modelDTO;

import com.react_java.reactjava.model.videovisto;
import lombok.Data;
import org.springframework.data.annotation.Id;

import java.util.List;

@Data
public class DBA_rhuDTO {


    public String getDba() {
        return dba;
    }

    public void setDba(String dba) {
        this.dba = dba;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public List<docentesDTO> getDocente() {
        return docente;
    }

    public void setDocente(List<docentesDTO> docente) {
        this.docente = docente;
    }

    private String dba;
    private String fecha;
    private List<docentesDTO> docente;
    private List<videovisto> videovisto;
}
