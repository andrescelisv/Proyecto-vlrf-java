package com.react_java.reactjava.modelDTO;

import com.react_java.reactjava.model.videovisto;
import lombok.Data;

import java.util.List;

@Data
public class comentarioDTO {

    private String comentario;
    private String fecha;
    private List<materiaDTO> materia;
    private List<gradoDTO> grado;
    private List<docentesDTO> docente;
    private List<estudiantesDTO> estudiante;
}
