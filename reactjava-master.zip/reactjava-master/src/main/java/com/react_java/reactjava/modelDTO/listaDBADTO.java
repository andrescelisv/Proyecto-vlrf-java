package com.react_java.reactjava.modelDTO;

import lombok.Data;

@Data
public class listaDBADTO {


    private String dba;




}
