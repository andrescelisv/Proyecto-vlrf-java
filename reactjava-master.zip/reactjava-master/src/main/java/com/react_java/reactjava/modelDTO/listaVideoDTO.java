package com.react_java.reactjava.modelDTO;

import lombok.Data;

@Data
public class listaVideoDTO {


    private String video;




}
