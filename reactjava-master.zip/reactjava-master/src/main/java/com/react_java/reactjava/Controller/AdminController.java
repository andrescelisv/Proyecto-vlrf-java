package com.react_java.reactjava.Controller;


import com.react_java.reactjava.Exceptionswrapper.ApiError;
import com.react_java.reactjava.Exceptionswrapper.RestExceptionHandler;
import com.react_java.reactjava.Exceptionswrapper.WrapperResponse;
import com.react_java.reactjava.Tarearepository.*;
import com.react_java.reactjava.commons.GenericServiceException;
import com.react_java.reactjava.commons.ValidateServiceException;

import com.react_java.reactjava.model.*;
import com.react_java.reactjava.modelDTO.materiaDTO;
import com.react_java.reactjava.services.*;
import com.react_java.reactjava.utils.jenaSparql;
import org.apache.jena.Jena;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.print.Doc;
import java.util.List;


@CrossOrigin(origins = "http://localhost:4200") //Habilita para que el cliente angular consulte la API sin ningún error
@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private TareaRepository tareaRepository;

    @Autowired
    private docentesRepository DocentesRepository;

    @Autowired
    private docentesServices DocentesServices;

    @Autowired
    private materiaRepository MateriaRepository;

    @Autowired
    private materiaServices MateriaServices;

    @Autowired
    private gradoRepository GradoRepository;

    @Autowired
    private gradoServices GradoServices;

    @Autowired
    private estudiantesServices EstudianteServices;

    @Autowired
    private estudianteRepository EstudianteRepository;

    @Autowired
    private institucionRepository InstitucionRepository;

    @Autowired
    private institucionServices InstitucionServices;

    @Autowired
    private usuarioServices UsuarioServices;

    @Autowired
    private departamento_municipioServices Departamento_municipioServices;


    @Autowired
    private usuarioRepository UsuarioRepository;

    @Autowired
    private rhuServices RHUServices;

    @Autowired
    private dbaServices DBAServices;

    @Autowired
    private ndServices NDServices;

    @Autowired
    private lvServices LVServices;

    @Autowired
    private val_videoServices Val_VideoServices;

    @Autowired
    private raServices RAServices;

    jenaSparql jena = new jenaSparql();

    @Autowired
    private comentarioServices ComentariosServices;

    Logger logger = LoggerFactory.getLogger(AdminController.class);

    @GetMapping("")
    List<Tareas> index(){
        System.out.println("Respondio");
        System.out.println(tareaRepository.findAll());

        return tareaRepository.findAll();
    }

    @RequestMapping(value = "/usuarios/all", method = RequestMethod.GET)
    public WrapperResponse<User> getallUser() {
        try {
            List<User> usuarios = UsuarioServices.getAllUser();
            WrapperResponse response = new WrapperResponse(true, "success", usuarios);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.CREATED)  //Respuestas de 201
    @PostMapping("/usuarios/addUsuarios")
    public WrapperResponse<User> crearUsuario(@RequestBody User Usuario) {

        try {
            User usuario1 = UsuarioServices.saveUser(Usuario);
            WrapperResponse response = new WrapperResponse(true, "success", usuario1);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }

    }

    @PutMapping("/usuarios/usuarioUpdate"+"/{id}")
    public WrapperResponse<User> updateUsuario(@PathVariable String id, @RequestBody User usuario) {
        System.out.println("llego");

        System.out.println(id);
        System.out.println("usuario"+usuario);
        try {
            User usuarioFromDb = UsuarioServices
                    .getByName(id);

            usuarioFromDb.setId(usuario.getId());
            usuarioFromDb.setUsername(usuario.getUsername());
            usuarioFromDb.setPassword(usuario.getPassword());
            usuarioFromDb.setRol(usuario.getRol());
            usuarioFromDb.setEmail(usuario.getEmail());

            UsuarioServices.saveUser(usuarioFromDb);

            WrapperResponse response = new WrapperResponse(true, "success", usuario);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("usuarios/deleteUsuario/{id}")
    public ResponseEntity<Object> deleteUsuario(@PathVariable String id){
        System.out.println("llego");

        System.out.println(id);

        try {
            User usuarioFromDb = UsuarioServices
                    .getByName(id);

            System.out.println("usuario: " + usuarioFromDb);
            //User respuesta= UsuarioServices.DeleteUser(usuarioFromDb);
            String respuesta = UsuarioServices.DeleteUserById(id);
            System.out.println("respuesta: "+respuesta);
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("Documento eliminado con exito ");

            String error = "Se elimino el registro del documento";


            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.ACCEPTED, error, ex));
            logger.info("Eliminando estudiante");
            logger.info(String.valueOf(val));
            return val;

        } catch(Exception e) {
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("No puede acceder al recurso solicitado");

            String error = "El documento no puede acceder a los registros";
            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, error, ex));
            return val;
        }

    }

    @RequestMapping(value = "/institucion/all", method = RequestMethod.GET)
    public WrapperResponse<User> getallInstitucion() {
        try {
            List<institucion> Institucion = InstitucionServices.getAllInstitucion();
            WrapperResponse response = new WrapperResponse(true, "success", Institucion);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }



    @RequestMapping(value = "/institucion/{orderId}", method = RequestMethod.GET)
    public WrapperResponse<materia> getInstitucionid(@PathVariable("orderId") String orderId) {
        try {
            List<institucion> instituciones = InstitucionServices.getAllInstitucion();
            WrapperResponse response = new WrapperResponse(true, "success", instituciones);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @RequestMapping(value = "/institucion/queryverificar", method = RequestMethod.GET)
    public WrapperResponse<institucion> InstitucionQueryVerificar(@RequestParam("nombre") String nombre,@RequestParam("departamento") String departamento,@RequestParam("municipio") String municipio,@RequestParam("zona") String zona) {
        try {
            System.out.println("id: "+nombre.toLowerCase());
            System.out.println("id: "+municipio);
            boolean institucion1 = InstitucionServices.Verificar(nombre,departamento,municipio,zona);
            WrapperResponse response = new WrapperResponse(true, "success", institucion1);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.CREATED)  //Respuestas de 201
    @PostMapping("/institucion/addInstitucion")
    public WrapperResponse<institucion> crearinstitucion(@RequestBody institucion instituciones) {

        try {
            institucion institucion1 = InstitucionServices.saveInstitucion(instituciones);
            WrapperResponse response = new WrapperResponse(true, "success", institucion1);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }

    }

    @PutMapping("/institucion/institucionUpdate"+"/{id}")
    public WrapperResponse<institucion> updateInstitucion(@PathVariable String id, @RequestBody institucion instituciones) {
        System.out.println("llego");

        System.out.println(id);
        System.out.println(instituciones);
        try {
            institucion institucionFromDb = InstitucionServices
                    .getByName(id);

            institucionFromDb.setNombre(instituciones.getNombre());
            institucionFromDb.setCorreoElectronico(instituciones.getCorreoElectronico());
            institucionFromDb.setJornada(instituciones.getJornada());
            institucionFromDb.setDepartamento(instituciones.getDepartamento());
            institucionFromDb.setMunicipio(instituciones.getMunicipio());
            institucionFromDb.setTelefono(instituciones.getTelefono());
            institucionFromDb.setUbicacion(instituciones.getUbicacion());
            institucionFromDb.setZona(instituciones.getZona());



            InstitucionServices.saveInstitucion(institucionFromDb);

            WrapperResponse response = new WrapperResponse(true, "success", instituciones);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("institucion/deleteEstudiante/{id}")
    public ResponseEntity<Object> deleteInstitucion(@PathVariable String id){
        System.out.println("llego");

        System.out.println(id);

        try {
            institucion institucionFromDb = InstitucionServices
                    .getByName(id);


            institucion respuesta= InstitucionServices.DeleteInstitucion(institucionFromDb);
            System.out.println(respuesta);
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("Documento eliminado con exito ");

            String error = "Se elimino el registro del documento";


            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.ACCEPTED, error, ex));
            logger.info("Eliminando estudiante");
            logger.info(String.valueOf(val));
            return val;

        } catch(Exception e) {
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("No puede acceder al recurso solicitado");

            String error = "El documento no puede acceder a los registros";
            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, error, ex));
            return val;
        }

    }

        @GetMapping("Materia/finbymateria")
    List<materia> pormateria (){
        System.out.println("Respondio");
        System.out.println(MateriaRepository.findAll());

        return MateriaRepository.findAll();
    }

    @RequestMapping(value = "/Materia/queryname/{orderId}", method = RequestMethod.GET)
    public WrapperResponse<materia> Materiaqueryname(@PathVariable("orderId") String orderId) {
        try {
            System.out.println("id: "+orderId);
            List<materia> Materia = MateriaServices.Name(orderId);
            WrapperResponse response = new WrapperResponse(true, "success", Materia);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @RequestMapping(value = "/Materia/queryverificar", method = RequestMethod.GET)
    public WrapperResponse<materia> MateriaQueryVerificar(@RequestParam("area") String area,@RequestParam("nombre") String nombre,@RequestParam("institucion") String institucion,@RequestParam("grado") String grado) {
        try {
            System.out.println("id: "+grado.toLowerCase());
            System.out.println("id: "+institucion);
            boolean materia1 = MateriaServices.Verificar(area,nombre,institucion,grado);
            WrapperResponse response = new WrapperResponse(true, "success", materia1);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }



    @RequestMapping(value = "/Materia/{orderId}", method = RequestMethod.GET)
    public WrapperResponse<materia> getMateriaid(@PathVariable("orderId") String orderId) {
        try {
            List<materia> materias = MateriaServices.getAllMateria();
            WrapperResponse response = new WrapperResponse(true, "success", materias);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.CREATED)  //Respuestas de 201
    @PostMapping("/Materia/addMateria")
    public WrapperResponse<materia> creardocente(@RequestBody materia materias){

        try {
            System.out.println("Materiasinicio: ");
            System.out.println("MateriasIn: "+materias);
            materia materiasin = MateriaServices.saveMateria(materias);
            System.out.println("MateriasOut: "+materiasin);
            WrapperResponse response = new WrapperResponse(true, "success", materiasin);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }

    }

    @PutMapping("/Materia/materiaUpdate"+"/{id}")
    public WrapperResponse<materia> updateMateria(@PathVariable String id, @RequestBody materia materias) {
        System.out.println("llego");

        System.out.println(id);
        System.out.println(materias);
        try {
            materia materiaFromDb = MateriaServices
                    .getByName(id);

            materiaFromDb.setGrado(materias.getGrado());


            MateriaServices.saveMateria(materiaFromDb);

            WrapperResponse response = new WrapperResponse(true, "success", materias);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("Materia/deleteMateria/{id}")
    public ResponseEntity<Object> deleteMateria(@PathVariable String id){
        System.out.println("llego");

        System.out.println(id);

        try {
            materia materiaFromDb = MateriaServices
                    .getByName(id);


            materia respuesta= MateriaServices.DeleteMateria(materiaFromDb);
            System.out.println(respuesta);
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("Documento eliminado con exito ");

            String error = "Se elimino el registro del documento";


            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.ACCEPTED, error, ex));
            logger.info("Eliminando estudiante");
            logger.info(String.valueOf(val));
            return val;

        } catch(Exception e) {
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("No puede acceder al recurso solicitado");

            String error = "El documento no puede acceder a los registros";
            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, error, ex));
            return val;
        }

    }


    @RequestMapping(value = "/Docente/all", method = RequestMethod.GET)
    public WrapperResponse<Docentes> getallDocentes() {
        try {
            List<Docentes> docentes = DocentesServices.getAllDocentes();
            WrapperResponse response = new WrapperResponse(true, "success", docentes);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @RequestMapping(value = "/Docente/queryname/{orderId}", method = RequestMethod.GET)
    public WrapperResponse<Docentes> Docentesqueryname(@PathVariable("orderId") String orderId) {
        try {
            System.out.println("id: "+orderId);
            List<Docentes> docente1 = DocentesServices.FindByInstitucion(orderId);
            WrapperResponse response = new WrapperResponse(true, "success", docente1);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @RequestMapping(value = "/docente/querynombreandcedula", method = RequestMethod.GET)
    public WrapperResponse<Docentes> DocenteQueryNameCedula(@RequestParam("nombre") String nombre,@RequestParam("cedula") String cedula) {
        try {
            System.out.println("id: "+nombre.toLowerCase());
            System.out.println("id: "+cedula);
            boolean docente1 = DocentesServices.Verificar(nombre,cedula);
            WrapperResponse response = new WrapperResponse(true, "success", docente1);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @RequestMapping(value = "/Docente/{orderId}", method = RequestMethod.GET)
    public WrapperResponse<Docentes> getDocenteid(@PathVariable("orderId") String orderId) {
        try {
            List<Docentes> docentes = DocentesServices.getAllDocentes();
            WrapperResponse response = new WrapperResponse(true, "success", docentes);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.CREATED)  //Respuestas de 201
    @PostMapping("Docente/addDocente")
    public WrapperResponse<Docentes> creardocente(@RequestBody Docentes docentesin){

        try {
            System.out.println("docentesin: "+docentesin);
            Docentes docentes = DocentesServices.saveDocente(docentesin);
            WrapperResponse response = new WrapperResponse(true, "success", docentes);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }

    }

    @PutMapping("/Docente/docenteUpdate"+"/{id}")
    public WrapperResponse<Docentes> updateDocente(@PathVariable String id, @RequestBody Docentes docentes) {
        System.out.println("llego");

        System.out.println(id);
        System.out.println(docentes);
        try {
            Docentes docentesFromDb = DocentesServices
                    .getByName(id);

            docentesFromDb.setGrado(docentes.getGrado());
            docentesFromDb.setCedula(docentes.getCedula());
            docentesFromDb.setFechaNacimiento(docentes.getFechaNacimiento());
            docentesFromDb.setCorreoElectronico(docentes.getCorreoElectronico());
            docentesFromDb.setNombre(docentes.getNombre());
            docentesFromDb.setMateria(docentes.getMateria());
            docentesFromDb.setInstitucion(docentes.getInstitucion());


            DocentesServices.saveDocente(docentesFromDb);

            WrapperResponse response = new WrapperResponse(true, "success", docentes);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }



    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("Docente/deleteDocente/{id}")
    public ResponseEntity<Object> deleteDocente(@PathVariable String id){
        System.out.println("llego");

        System.out.println(id);

        try {
            Docentes docenteFromDb = DocentesServices
                    .getByName(id);


            Docentes respuesta= DocentesServices.DeleteDocente(docenteFromDb);
            System.out.println(respuesta);
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("Documento eliminado con exito ");

            String error = "Se elimino el registro del documento";


            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.ACCEPTED, error, ex));
            logger.info("Eliminando estudiante");
            logger.info(String.valueOf(val));
            return val;

        } catch(Exception e) {
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("No puede acceder al recurso solicitado");

            String error = "El documento no puede acceder a los registros";
            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, error, ex));
            return val;
        }

    }

    @GetMapping("Grado/finbygrado")
    List<grado> porgrado (){
        System.out.println("Respondio");
        System.out.println(GradoRepository.findAll());

        return GradoRepository.findAll();
    }

    @RequestMapping(value = "/Grado/all", method = RequestMethod.GET)
    public WrapperResponse<grado> getallGrado() {
        try {
            List<grado> grados = GradoServices.getAllGrados();
            WrapperResponse response = new WrapperResponse(true, "success", grados);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @RequestMapping(value = "/Grado/queryname/{orderId}", method = RequestMethod.GET)
    public WrapperResponse<grado> Gradoqueryname(@PathVariable("orderId") String orderId) {
        try {
            System.out.println("id: "+orderId);
            List<grado> Grado = GradoServices.Name(orderId);
            WrapperResponse response = new WrapperResponse(true, "success", Grado);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @RequestMapping(value = "/Grado/queryverificargrado", method = RequestMethod.GET)
    public WrapperResponse<grado> GradoQueryVerificar(@RequestParam("grado") String grado,@RequestParam("jornada") String jornada,@RequestParam("grupo") String grupo,@RequestParam("institucion") String institucion) {
        try {
            System.out.println("id: "+grado.toLowerCase());
            System.out.println("id: "+institucion);
            boolean grado1 = GradoServices.Verificar(grado,jornada,grupo,institucion);
            WrapperResponse response = new WrapperResponse(true, "success", grado1);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @RequestMapping(value = "/Grado/{orderId}", method = RequestMethod.GET)
    public WrapperResponse<grado> getGradoid(@PathVariable("orderId") String orderId) {
        try {
            List<grado> Grado = GradoServices.getAllGrados();
            WrapperResponse response = new WrapperResponse(true, "success", Grado);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.CREATED)  //Respuestas de 201
    @PostMapping("/Grado/addGrado")
    public WrapperResponse<grado> creargrado(@RequestBody grado Grado){

        try {
            grado gradoin = GradoServices.saveEstudiante(Grado);
            WrapperResponse response = new WrapperResponse(true, "success", gradoin);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }

    }

    @PutMapping("/Grado/gradoUpdate"+"/{id}")
    public WrapperResponse<grado> updateGrado(@PathVariable String id, @RequestBody grado Grado) {
        System.out.println("llego");

        System.out.println(id);
        System.out.println(Grado);
        try {
            grado gradoFromDb = GradoServices
                    .getByName(id);

            gradoFromDb.setGrado(Grado.getGrado());
            gradoFromDb.setGrupo(Grado.getGrupo());
            gradoFromDb.setInstitucion(Grado.getInstitucion());
            gradoFromDb.setJornada(Grado.getJornada());




            GradoServices.saveEstudiante(gradoFromDb);

            WrapperResponse response = new WrapperResponse(true, "success", Grado);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("Grado/deleteGrado/{id}")
    public ResponseEntity<Object> deleteGrado(@PathVariable String id){
        System.out.println("llego");

        System.out.println(id);

        try {
            grado gradoFromDb = GradoServices
                    .getByName(id);


            grado respuesta= GradoServices.DeleteEstudiante(gradoFromDb);
            System.out.println(respuesta);
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("Documento eliminado con exito ");

            String error = "Se elimino el registro del documento";


            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.ACCEPTED, error, ex));
            logger.info("Eliminando estudiante");
            logger.info(String.valueOf(val));
            return val;

        } catch(Exception e) {
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("No puede acceder al recurso solicitado");

            String error = "El documento no puede acceder a los registros";
            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, error, ex));
            return val;
        }

    }

    @RequestMapping(value = "/Estudiante/queryname/{orderId}", method = RequestMethod.GET)
    public WrapperResponse<Estudiante> Estudiantequeryname(@PathVariable("orderId") String orderId) {
        try {
            System.out.println("id: "+orderId);
            List<Estudiante> estudiantes = EstudianteServices.FindByInstitucion(orderId);
            WrapperResponse response = new WrapperResponse(true, "success", estudiantes);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @RequestMapping(value = "/estudiante/querynombreandcedula", method = RequestMethod.GET)
    public WrapperResponse<Estudiante> EstudianteQueryNameCedula(@RequestParam("nombre") String nombre,@RequestParam("cedula") String cedula) {
        try {
            System.out.println("id: "+nombre.toLowerCase());
            System.out.println("id: "+cedula);
            boolean estudiante1 = EstudianteServices.Verificar(nombre,cedula);
            WrapperResponse response = new WrapperResponse(true, "success", estudiante1);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @RequestMapping(value = "/estudiante/all", method = RequestMethod.GET)
    public WrapperResponse<Estudiante> getallEstudiante() {
        try {
            List<Estudiante> estudiante = EstudianteServices.getAllEstudiantes();
            WrapperResponse response = new WrapperResponse(true, "success", estudiante);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @GetMapping("estudiante/finbyestudiante")
    public WrapperResponse<Estudiante> getEstudiante() {
        try {
            List<Estudiante> estudiante = EstudianteServices.getAllEstudiantes();
            WrapperResponse response = new WrapperResponse(true, "success", estudiante);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }


    @RequestMapping(value = "/estudiante/{orderId}", method = RequestMethod.GET)
    public WrapperResponse<Estudiante> getEstudianteid(@PathVariable("orderId") String orderId) {
        try {
            Estudiante estudiante = EstudianteServices.getByName(orderId);
            WrapperResponse response = new WrapperResponse(true, "success", estudiante);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.CREATED)  //Respuestas de 201
    @PostMapping("estudiante/addEstudiante")
    public WrapperResponse<Estudiante> crearestudiante(@RequestBody Estudiante estudiantein){

        try {
            Estudiante estudiante = EstudianteServices.saveEstudiante(estudiantein);
            WrapperResponse response = new WrapperResponse(true, "success", estudiante);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }

    }

    @PutMapping("estudiante/estudiantesUpdate"+"/{id}")
    public WrapperResponse<Estudiante> updateEstudiantes(@PathVariable String id, @RequestBody Estudiante estudiante){
        System.out.println("llego");

        System.out.println(id);
        System.out.println(estudiante);
        try {
            Estudiante estudianteFromDb = EstudianteServices
                    .getByName(id);

            estudianteFromDb.setFechaNacimiento(estudiante.getFechaNacimiento());
            estudianteFromDb.setMateria(estudiante.getMateria());
            estudianteFromDb.setCedula(estudiante.getCedula());
            estudianteFromDb.setGrado(estudiante.getGrado());
            estudianteFromDb.setInstitucion(estudiante.getInstitucion());
            estudianteFromDb.setNombre(estudiante.getNombre());
            estudianteFromDb.setId(estudiante.getId());
            estudianteFromDb.setCorreoElectronico(estudiante.getCorreoElectronico());


            EstudianteServices.saveEstudiante(estudianteFromDb);

            WrapperResponse response = new WrapperResponse(true, "success", estudiante);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }



    }

    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("estudiante/deleteEstudiante/{id}")
    public ResponseEntity<Object> deleteEstudiante(@PathVariable String id){
        System.out.println("llego");

        System.out.println(id);

        try {
            Estudiante estudianteFromDb = EstudianteServices
                    .getByName(id);


          Estudiante  respuesta= EstudianteServices.DeleteEstudiante(estudianteFromDb);
           System.out.println(respuesta);
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("Documento con eliminado con exito ");

            String error = "Se elimino el registro del documento";


            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.ACCEPTED, error, ex));
            logger.info("Eliminando estudiante");
            logger.info(String.valueOf(val));
            return val;

        } catch(Exception e) {
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("No puede acceder al recurso solicitado");

            String error = "El documento no puede acceder a los registros";
            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, error, ex));
            return val;
        }

    }

    @RequestMapping(value = "/Departamento_municipio/queryname/{orderId}", method = RequestMethod.GET)
    public WrapperResponse<Departamento_municipio> Departamento_municipio_queryname(@PathVariable("orderId") String orderId) {
        try {
            System.out.println("id: "+orderId);
            List<Departamento_municipio> departamento_municipio = Departamento_municipioServices.getQueryDepartamento(orderId);
            WrapperResponse response = new WrapperResponse(true, "success", departamento_municipio);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }


    @RequestMapping(value = "/RHU/all", method = RequestMethod.GET)
    public WrapperResponse<RHU> getallRHU() {
        try {
            List<RHU> rhu = RHUServices.getAllRHU();
            System.out.println("valor de rhu: "+rhu);
            WrapperResponse response = new WrapperResponse(true, "success", rhu);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.CREATED)  //Respuestas de 201
    @PostMapping("/RHU/addRHU")
    public WrapperResponse<RHU> crearRHU(@RequestBody RHU rhu) {

        try {
            RHU rhu1 = RHUServices.saveRHU(rhu);
            WrapperResponse response = new WrapperResponse(true, "success", rhu1);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }

    }

    @RequestMapping(value = "/RHU/queryverificar", method = RequestMethod.GET)
    public WrapperResponse<RHU> RHUQueryNameCedula(@RequestParam("fecha") String fecha,@RequestParam("institucion") String institucion) {
        try {
            System.out.println("id: "+fecha.toLowerCase());
            System.out.println("id: "+institucion);
            boolean rhu1 = RHUServices.Verificar(fecha,institucion);
            WrapperResponse response = new WrapperResponse(true, "success", rhu1);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }



    @PutMapping("/RHU/rhuUpdate"+"/{id}")
    public WrapperResponse<RHU> updateRHU(@PathVariable String id, @RequestBody RHU rhu) {
        System.out.println("llego");

        System.out.println(id);
        System.out.println("rhu"+rhu);
        try {
            RHU rhuFromDb = RHUServices
                    .getByName(id);

            rhuFromDb.setId(rhu.getId());
            rhuFromDb.setDba(rhu.getDba());
            rhuFromDb.setEstudiante(rhu.getEstudiante());
            rhuFromDb.setInstitucion(rhu.getInstitucion());


            RHUServices.saveRHU(rhuFromDb);

            WrapperResponse response = new WrapperResponse(true, "success", rhu);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("RHU/deleteRHU/{id}")
    public ResponseEntity<Object> deleteRHU(@PathVariable String id){
        System.out.println("llego");

        System.out.println(id);

        try {
            RHU rhuFromDb = RHUServices
                    .getByName(id);

            System.out.println("usuario: " + rhuFromDb);
            //User respuesta= UsuarioServices.DeleteUser(usuarioFromDb);
            String respuesta = RHUServices.DeleteRHUById(id);
            System.out.println("respuesta: "+respuesta);
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("Documento eliminado con exito ");

            String error = "Se elimino el registro del documento";


            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.ACCEPTED, error, ex));
            logger.info("Eliminando estudiante");
            logger.info(String.valueOf(val));
            return val;

        } catch(Exception e) {
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("No puede acceder al recurso solicitado");

            String error = "El documento no puede acceder a los registros";
            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, error, ex));
            return val;
        }

    }

    @RequestMapping(value = "/ND/all", method = RequestMethod.GET)
    public WrapperResponse<ND> getallND() {
        try {
            List<ND> nd = NDServices.getAllND();
            System.out.println("valor de rhu: "+nd);
            WrapperResponse response = new WrapperResponse(true, "success", nd);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.CREATED)  //Respuestas de 201
    @PostMapping("/ND/addND")
    public WrapperResponse<ND> crearND(@RequestBody ND nd) {

        try {
            ND nd1 = NDServices.saveND(nd);
            WrapperResponse response = new WrapperResponse(true, "success", nd1);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }

    }

    @RequestMapping(value = "/ND/queryverificar", method = RequestMethod.GET)
    public WrapperResponse<ND> NDQueryVerificar(@RequestParam("dba") String dba,@RequestParam("estudiante") String estudiante,@RequestParam("docente") String docente,@RequestParam("institucion") String institucion) {
        try {
            System.out.println("id: "+dba.toLowerCase());
            System.out.println("id: "+institucion);
            boolean nd1 = NDServices.Verificar(dba,estudiante,docente,institucion);
            WrapperResponse response = new WrapperResponse(true, "success", nd1);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }



    @PutMapping("/nd/ndUpdate"+"/{id}")
    public WrapperResponse<ND> updateND(@PathVariable String id, @RequestBody ND nd) {
        System.out.println("llego");

        System.out.println(id);
        System.out.println("nd"+nd);
        try {
            ND ndFromDb = NDServices
                    .getByName(id);

            ndFromDb.setId(nd.getId());
            ndFromDb.setNd(nd.getNd());
            ndFromDb.setEstudiante(nd.getEstudiante());


            NDServices.saveND(ndFromDb);

            WrapperResponse response = new WrapperResponse(true, "success", nd);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("ND/deleteND/{id}")
    public ResponseEntity<Object> deleteND(@PathVariable String id){
        System.out.println("llego");

        System.out.println(id);

        try {
            ND ndFromDb = NDServices
                    .getByName(id);

            System.out.println("usuario: " + ndFromDb);
            //User respuesta= UsuarioServices.DeleteUser(usuarioFromDb);
            String respuesta = NDServices.DeleteNDById(id);
            System.out.println("respuesta: "+respuesta);
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("Documento eliminado con exito ");

            String error = "Se elimino el registro del documento";


            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.ACCEPTED, error, ex));
            logger.info("Eliminando estudiante");
            logger.info(String.valueOf(val));
            return val;

        } catch(Exception e) {
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("No puede acceder al recurso solicitado");

            String error = "El documento no puede acceder a los registros";
            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, error, ex));
            return val;
        }

    }

    @RequestMapping(value = "/DBA/all", method = RequestMethod.GET)
    public WrapperResponse<dba> getallDBA() {
        try {
            List<dba> dba1 = DBAServices.getAllDBA();
            WrapperResponse response = new WrapperResponse(true, "success", dba1);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.CREATED)  //Respuestas de 201
    @PostMapping("/DBA/addDBA")
    public WrapperResponse<dba> crearDBA(@RequestBody dba dba1) {

        try {
            dba dba2 = DBAServices.saveDBA(dba1);
            WrapperResponse response = new WrapperResponse(true, "success", dba2);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }

    }

    @PutMapping("/DBA/dbaUpdate"+"/{id}")
    public WrapperResponse<dba> updateDBA(@PathVariable String id, @RequestBody dba dba1) {
        System.out.println("llego");

        System.out.println(id);
        System.out.println("rhu"+dba1);
        try {
            dba dbaFromDb = DBAServices
                    .getByName(id);

            dbaFromDb.setIdentificador(dba1.getIdentificador());
            dbaFromDb.setMateria(dba1.getMateria());
            dbaFromDb.setGrado(dba1.getGrado());
            dbaFromDb.setDba(dba1.getDba());


            DBAServices.saveDBA(dbaFromDb);

            WrapperResponse response = new WrapperResponse(true, "success", dba1);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("DBA/deleteDBA/{id}")
    public ResponseEntity<Object> deleteDBA(@PathVariable String id){
        System.out.println("llego");

        System.out.println(id);

        try {
            dba dbaFromDb = DBAServices
                    .getByName(id);

            System.out.println("usuario: " + dbaFromDb);
            //User respuesta= UsuarioServices.DeleteUser(usuarioFromDb);
            String respuesta = DBAServices.DeleteDBAById(id);
            System.out.println("respuesta: "+respuesta);
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("Documento eliminado con exito ");

            String error = "Se elimino el registro del documento";


            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.ACCEPTED, error, ex));
            logger.info("Eliminando estudiante");
            logger.info(String.valueOf(val));
            return val;

        } catch(Exception e) {
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("No puede acceder al recurso solicitado");

            String error = "El documento no puede acceder a los registros";
            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, error, ex));
            return val;
        }

    }

    @RequestMapping(value = "/LV/all", method = RequestMethod.GET)
    public WrapperResponse<LV> getallLV() {
        try {
            List<LV> lv = LVServices.getAllLV();
            System.out.println("valor de lv: "+lv);
            WrapperResponse response = new WrapperResponse(true, "success", lv);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @RequestMapping(value = "/LV/queryestudiante/{orderId}", method = RequestMethod.GET)
    public WrapperResponse<LV> LVEstudianteQueryName(@PathVariable("orderId") String orderId) {
        try {
            System.out.println("id: "+orderId);
            List<LV> lv = LVServices.FindByEstudiante(orderId);
            WrapperResponse response = new WrapperResponse(true, "success", lv);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.CREATED)  //Respuestas de 201
    @PostMapping("/LV/addLV")
    public WrapperResponse<LV> crearLV(@RequestBody LV lv) {

        try {
            LV lv1 = LVServices.saveLV(lv);
            WrapperResponse response = new WrapperResponse(true, "success", lv1);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }

    }

    @RequestMapping(value = "/LV/queryverificar", method = RequestMethod.GET)
    public WrapperResponse<LV> LVQueryVerificar(@RequestParam("dba") String dba,@RequestParam("estudiante") String estudiante,@RequestParam("docente") String docente,@RequestParam("institucion") String institucion) {
        try {
            System.out.println("id: "+dba.toLowerCase());
            System.out.println("id: "+institucion);
            boolean lv1 = LVServices.Verificar(dba,estudiante,docente,institucion);
            WrapperResponse response = new WrapperResponse(true, "success", lv1);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @PutMapping("/LV/lvUpdate"+"/{id}")
    public WrapperResponse<LV> updateRHU(@PathVariable String id, @RequestBody LV lv) {
        System.out.println("llego");

        System.out.println(id);
        System.out.println("rhu"+lv);
        try {
            LV lvFromDb = LVServices
                    .getByName(id);

            lvFromDb.setId(lv.getId());
            lvFromDb.setLv(lv.getLv());
            lvFromDb.setEstudiante(lv.getEstudiante());
            lvFromDb.setInstitucion(lv.getInstitucion());


            LVServices.saveLV(lvFromDb);

            WrapperResponse response = new WrapperResponse(true, "success", lv);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("LV/deleteLV/{id}")
    public ResponseEntity<Object> deleteLV(@PathVariable String id){
        System.out.println("llego");

        System.out.println(id);

        try {
            LV lvFromDb = LVServices
                    .getByName(id);

            System.out.println("usuario: " + lvFromDb);
            //User respuesta= UsuarioServices.DeleteUser(usuarioFromDb);
            String respuesta = LVServices.DeleteLVById(id);
            System.out.println("respuesta: "+respuesta);
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("Documento eliminado con exito ");

            String error = "Se elimino el registro del documento";


            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.ACCEPTED, error, ex));
            logger.info("Eliminando estudiante");
            logger.info(String.valueOf(val));
            return val;

        } catch(Exception e) {
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("No puede acceder al recurso solicitado");

            String error = "El documento no puede acceder a los registros";
            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, error, ex));
            return val;
        }

    }

    @RequestMapping(value = "/ValVideos/all", method = RequestMethod.GET)
    public WrapperResponse<val_video> getallValVideo() {
        try {
            List<val_video> val_video1 = Val_VideoServices.getAllval_video();
            System.out.println("valor de lv: "+val_video1);
            WrapperResponse response = new WrapperResponse(true, "success", val_video1);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @RequestMapping(value = "/ValVideos/queryestudianteVideo", method = RequestMethod.GET)
    public WrapperResponse<val_video> ValVideoEstudianteQueryName(@RequestParam("videourl") String videourl,@RequestParam("name") String name) {
        try {
            System.out.println("id: "+videourl);
            System.out.println("id: "+name);
            boolean val_video1 = Val_VideoServices.Verificar(videourl,name);
            WrapperResponse response = new WrapperResponse(true, "success", val_video1);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.CREATED)  //Respuestas de 201
    @PostMapping("/ValVideos/addValVideos")
    public WrapperResponse<val_video> crearLV(@RequestBody val_video ValVideo) {

        try {
            val_video valvideo1 = Val_VideoServices.saveValVideo(ValVideo);
            WrapperResponse response = new WrapperResponse(true, "success", valvideo1);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }

    }

    @PutMapping("/ValVideos/ValVideosUpdate"+"/{id}")
    public WrapperResponse<val_video> updateValVideos(@PathVariable String id, @RequestBody val_video val_video1) {
        System.out.println("llego");

        System.out.println(id);
        System.out.println("rhu"+val_video1);
        try {
            val_video ValVideoFromDb = Val_VideoServices
                    .getByName(id);

            ValVideoFromDb.setId(val_video1.getId());
            ValVideoFromDb.setVal(val_video1.getVal());
            ValVideoFromDb.setEstudiante(val_video1.getEstudiante());
            ValVideoFromDb.setInstitucion(val_video1.getInstitucion());


            Val_VideoServices.saveValVideo(ValVideoFromDb);

            WrapperResponse response = new WrapperResponse(true, "success", val_video1);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("ValVideos/deleteValVideos/{id}")
    public ResponseEntity<Object> deleteValVideos(@PathVariable String id){
        System.out.println("llego");

        System.out.println(id);

        try {
            val_video ValVideoFromDb = Val_VideoServices
                    .getByName(id);

            System.out.println("usuario: " + ValVideoFromDb);
            //User respuesta= UsuarioServices.DeleteUser(usuarioFromDb);
            String respuesta = Val_VideoServices.DeleteLVal_VideoById(id);
            System.out.println("respuesta: "+respuesta);
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("Documento eliminado con exito ");

            String error = "Se elimino el registro del documento";


            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.ACCEPTED, error, ex));
            logger.info("Eliminando estudiante");
            logger.info(String.valueOf(val));
            return val;

        } catch(Exception e) {
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("No puede acceder al recurso solicitado");

            String error = "El documento no puede acceder a los registros";
            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, error, ex));
            return val;
        }

    }

    @RequestMapping(value = "/RA/all", method = RequestMethod.GET)
    public WrapperResponse<RA> getallRA() {
        try {
            List<RA> ra1 = RAServices.getAllRA();
            System.out.println("valor de lv: "+ra1);
            WrapperResponse response = new WrapperResponse(true, "success", ra1);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @RequestMapping(value = "/RA/queryestudianteRA", method = RequestMethod.GET)
    public WrapperResponse<RA> RAEstudianteQueryName(@RequestParam("nombreestudiante") String nombreestudiante,@RequestParam("nombremateria") String nombremateria,@RequestParam("grado") String grado,@RequestParam("nombredocente") String nombredocente) {
        try {
            System.out.println("id: "+nombremateria);
            System.out.println("id: "+nombreestudiante);
            System.out.println("id: "+nombredocente);
            boolean ra1 = RAServices.Verificar(nombreestudiante,nombremateria,grado,nombredocente);
            WrapperResponse response = new WrapperResponse(true, "success", ra1);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.CREATED)  //Respuestas de 201
    @PostMapping("/RA/addRA")
    public WrapperResponse<RA> crearRA(@RequestBody RA ra) {

        try {
            RA ra1 = RAServices.saveRA(ra);
            WrapperResponse response = new WrapperResponse(true, "success", ra1);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }

    }

    @PutMapping("/RA/RAUpdate"+"/{id}")
    public WrapperResponse<RA> updateRA(@PathVariable String id, @RequestBody RA ra1) {
        System.out.println("llego");

        System.out.println(id);
        System.out.println("rhu"+ra1);
        try {
            RA RAFromDb = RAServices
                    .getByName(id);

            RAFromDb.setId(ra1.getId());
            RAFromDb.setDba(ra1.getDba());
            RAFromDb.setEstudiante(ra1.getEstudiante());
            RAFromDb.setInstitucion(ra1.getInstitucion());
            RAFromDb.setDocente(ra1.getDocente());
            RAFromDb.setGrado(ra1.getGrado());
            RAFromDb.setFecha(ra1.getFecha());


            RAServices.saveRA(RAFromDb);

            WrapperResponse response = new WrapperResponse(true, "success", ra1);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("RA/deleteRA/{id}")
    public ResponseEntity<Object> deleteRA(@PathVariable String id){
        System.out.println("llego");

        System.out.println(id);

        try {
            RA RAFromDb = RAServices
                    .getByName(id);

            System.out.println("usuario: " + RAFromDb);
            //User respuesta= UsuarioServices.DeleteUser(usuarioFromDb);
            String respuesta = RAServices.DeleteRAById(id);
            System.out.println("respuesta: "+respuesta);
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("Documento eliminado con exito ");

            String error = "Se elimino el registro del documento";


            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.ACCEPTED, error, ex));
            logger.info("RA eliminado con exito");
            logger.info(String.valueOf(val));
            return val;

        } catch(Exception e) {
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("No puede acceder al recurso solicitado");

            String error = "El documento no puede acceder a los registros";
            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, error, ex));
            return val;
        }

    }

    @RequestMapping(value = "/comentarios/all", method = RequestMethod.GET)
    public WrapperResponse<comentarios> getallcomentarios() {
        try {
            List<comentarios> comentario1 = ComentariosServices.getAllcomentario();
            System.out.println("valor de lv: "+comentario1);
            WrapperResponse response = new WrapperResponse(true, "success", comentario1);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @RequestMapping(value = "/comentario/queryestudianteComentario", method = RequestMethod.GET)
    public WrapperResponse<comentarios> ComentarioEstudianteQueryName(@RequestParam("nombreestudiante") String nombreestudiante,@RequestParam("nombremateria") String nombremateria,@RequestParam("grado") String grado,@RequestParam("nombredocente") String nombredocente) {
        try {
            System.out.println("id: "+nombremateria);
            System.out.println("id: "+nombreestudiante);
            System.out.println("id: "+nombredocente);
            boolean comentario1 = ComentariosServices.Verificar(nombreestudiante,nombremateria,grado,nombredocente);
            WrapperResponse response = new WrapperResponse(true, "success", comentario1);
            return response;
        } catch(ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        }catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.CREATED)  //Respuestas de 201
    @PostMapping("/comentario/addCOMENTARIO")
    public WrapperResponse<comentarios> crearRA(@RequestBody comentarios comentario) {

        try {
            comentarios comentario1 = ComentariosServices.savecomentario(comentario);
            WrapperResponse response = new WrapperResponse(true, "success", comentario1);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }

    }

    @PutMapping("/comentario/COMENTARIOUpdate"+"/{id}")
    public WrapperResponse<comentarios> updateCOMENTARIO(@PathVariable String id, @RequestBody comentarios comentario1) {
        System.out.println("llego");

        System.out.println(id);
        System.out.println("rhu"+comentario1);
        try {
            comentarios COMENTARIOFromDb = ComentariosServices
                    .getBycomentario(id);

            COMENTARIOFromDb.setId(comentario1.getId());
            COMENTARIOFromDb.setComentario(comentario1.getComentario());
            COMENTARIOFromDb.setVideourl(comentario1.getVideourl());


            ComentariosServices.savecomentario(COMENTARIOFromDb);

            WrapperResponse response = new WrapperResponse(true, "success", comentario1);
            return response;
        } catch (ValidateServiceException e) {
            return new WrapperResponse(false, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("comentario/deleteCOMENTARIO/{id}")
    public ResponseEntity<Object> deleteCOMENTARIO(@PathVariable String id){
        System.out.println("llego");

        System.out.println(id);

        try {
            comentarios COMENTARIOFromDb = ComentariosServices
                    .getBycomentario(id);

            System.out.println("usuario: " + COMENTARIOFromDb);
            //User respuesta= UsuarioServices.DeleteUser(usuarioFromDb);
            String respuesta = ComentariosServices.DeletecomentarioById(id);
            System.out.println("respuesta: "+respuesta);
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("Documento eliminado con exito ");

            String error = "Se elimino el registro del documento";


            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.ACCEPTED, error, ex));
            logger.info("RA eliminado con exito");
            logger.info(String.valueOf(val));
            return val;

        } catch(Exception e) {
            RestExceptionHandler restExceptionHandler =new RestExceptionHandler();
            Throwable ex = new Throwable("No puede acceder al recurso solicitado");

            String error = "El documento no puede acceder a los registros";
            ResponseEntity<Object> val = restExceptionHandler.buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, error, ex));
            return val;
        }

    }

    @RequestMapping(value = "/videoresourcekeyword/{orderId}", method = RequestMethod.GET)
    public WrapperResponse<String > getKeywordid(@PathVariable("orderId") String orderId) {
        try {
            List<String> videoresource1= jena.videoResourceKeyword(orderId.toString());
            WrapperResponse response = new WrapperResponse(true, "success", videoresource1);
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @RequestMapping(value = "/dba", method = RequestMethod.GET)
    public WrapperResponse<String > getdbaid(@RequestParam("grado") String grado,@RequestParam("materia") String materia) {
        try {
            List<String> dba1= jena.dba(materia.toString(),grado.toString());
            WrapperResponse response = new WrapperResponse(true, "success", dba1);
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            return new WrapperResponse(false, "Internal Server Error");
        }
    }

    @GetMapping("/finbyestudianteRepository")
    List<Estudiante> estudiante (){
        System.out.println("Respondio");
        System.out.println(EstudianteRepository.findAll());

        return EstudianteRepository.findAll();
    }

/*
    @GetMapping("/finbymateria")
    List<materiaDTO> buscard(){
        System.out.println("Respondio");
        System.out.println(MateriaRepository.findAll());

        try {
            materiaConverter converter= new materiaConverter();
            return converter.toDtoList(MateriaRepository.findAll());
        } catch (Exception e) {
            e.printStackTrace();
            try {
                throw new Exception(e.getMessage(),e);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return null;
    }

      /*  return MateriaRepository.findAll();
    }*/

    @ResponseStatus(HttpStatus.CREATED)  //Respuestas de 201
    @PostMapping("tareas")
    Tareas create(@RequestBody Tareas tarea){
        return tareaRepository.save(tarea);
    }

    @ResponseStatus(HttpStatus.CREATED)  //Respuestas de 201
    @PostMapping("institucion")
    institucion create(@RequestBody institucion Institucion){
        return InstitucionRepository.save(Institucion);
    }



    @PutMapping("{id}")
    Tareas update(@PathVariable String id, @RequestBody Tareas tarea){
        System.out.println("llego");
        System.out.println(id);
        System.out.println(tarea);
        Tareas tareaFromDb = tareaRepository
                .findById(id)
                .orElseThrow(RuntimeException::new);

        tareaFromDb.setDocentes(tarea.getDocentes());


        return tareaRepository.save(tareaFromDb);


    }
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("{id}")
    void delete(@PathVariable String id){
        Tareas tarea = tareaRepository
                .findById(id)
                .orElseThrow(RuntimeException::new);
        tareaRepository.delete(tarea);
    }



}
