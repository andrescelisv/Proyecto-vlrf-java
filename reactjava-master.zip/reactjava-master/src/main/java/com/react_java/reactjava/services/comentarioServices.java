package com.react_java.reactjava.services;

import com.react_java.reactjava.Tarearepository.comentarioRepository;
import com.react_java.reactjava.Tarearepository.rhuRepository;
import com.react_java.reactjava.commons.GenericServiceException;
import com.react_java.reactjava.commons.ValidateServiceException;
import com.react_java.reactjava.model.RA;
import com.react_java.reactjava.model.RHU;
import com.react_java.reactjava.model.comentarios;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class comentarioServices {

    private static final Logger logger = LoggerFactory.getLogger(comentarioServices.class);

    @Autowired
    private comentarioRepository ComentarioRepository;

    public List<comentarios> getAllcomentario() throws GenericServiceException, ValidateServiceException {
        try {
            List<comentarios> comentario = ComentarioRepository.findAll();
            return comentario;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public comentarios getBycomentario(String idstr) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(idstr);
            String id=idstr;
            comentarios comentario1 = ComentarioRepository.findById(id).orElseThrow(RuntimeException::new);
            return comentario1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public boolean Verificar(String nombreEstudiante, String nombremateria,String grado, String nombredocente) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println(nombreEstudiante+":"+nombremateria+":"+nombredocente+":"+grado);
            System.out.println(nombreEstudiante.contains("/"));

            List<comentarios> comentario1= ComentarioRepository.findByEstudianteAndRA(nombreEstudiante,nombremateria,grado,nombredocente,"hola");
            System.out.println(comentario1);

            if(comentario1.size() == 0 ){
                System.out.println("No existen estos valores");
                return false;
            }
            else{
                System.out.println("Es igual");
                return true;
            }



        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public comentarios savecomentario(comentarios comentario) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println("usuario save: "+comentario);
            comentarios comentario1 = ComentarioRepository.save(comentario);
            return comentario1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public comentarios Deletecomentario(comentarios comentario) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println(comentario);
            ComentarioRepository.delete(comentario);


            return comentario;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public String DeletecomentarioById(String id) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println(id);
            ComentarioRepository.deleteById(id);


            return id;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }


}
