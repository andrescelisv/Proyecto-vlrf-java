package com.react_java.reactjava.model;

import com.react_java.reactjava.modelDTO.gradoDTO;
import com.react_java.reactjava.modelDTO.institucionDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@AllArgsConstructor
@Document(collection = "Materia")
public class materia {

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Id
    private String id;
    private String nombre;
    private String area;
    private List<gradoDTO> grado;
    private List<institucionDTO> institucion;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public List<gradoDTO> getGrado() {
        return grado;
    }

    public void setGrado(List<gradoDTO> grado) {
        this.grado = grado;
    }

    public List<institucionDTO> getInstitucion() {
        return institucion;
    }

    public void setInstitucion(List<institucionDTO> institucion) {
        this.institucion = institucion;
    }







}
