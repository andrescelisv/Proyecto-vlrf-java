package com.react_java.reactjava.modelDTO;

import lombok.Data;
import org.springframework.data.annotation.Id;

@Data
public class materiaDTO {
    @Id
    private String id;

    private String nombre;

}
