package com.react_java.reactjava.model;

import com.react_java.reactjava.modelDTO.departamento_municipioDTO;
import com.react_java.reactjava.modelDTO.institucionDTO;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@Document(collection = "Departamentos_municipios_colombia")
public class Departamento_municipio {
    @Id
    private String id;

    private String region;
    private String departamento;
    private String municipio;

}
