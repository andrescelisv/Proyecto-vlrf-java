package com.react_java.reactjava.Tarearepository;

import com.react_java.reactjava.model.Docentes;
import com.react_java.reactjava.model.Estudiante;
import com.react_java.reactjava.model.Tareas;
import com.react_java.reactjava.model.materia;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface docentesRepository extends MongoRepository<Docentes,String> {
    @Query("{ $and:[{nombre:?0},{cedula:?1}]}")
    List<Docentes> findBynombreAndcedula(String nombre, String cedula, String value);

    @Query("{ 'institucion.nombre': ?0},{nombre:true, id:true}")
    List<Docentes> findByInstitucion(String name, String value);




}
