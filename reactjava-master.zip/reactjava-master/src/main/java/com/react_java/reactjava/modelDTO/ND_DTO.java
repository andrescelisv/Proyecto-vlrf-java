package com.react_java.reactjava.modelDTO;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
public class ND_DTO {

    @NotNull
    private String dba;

    @NotEmpty
    private double nd;

    @NotNull
    @NotEmpty
    private String fecha;

    @NotEmpty
    @NotNull
    private List<docentesDTO> docente;







}
