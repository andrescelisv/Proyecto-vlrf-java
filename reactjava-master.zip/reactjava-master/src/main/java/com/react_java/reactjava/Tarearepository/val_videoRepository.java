package com.react_java.reactjava.Tarearepository;

import com.react_java.reactjava.model.LV;
import com.react_java.reactjava.model.RHU;
import com.react_java.reactjava.model.val_video;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface val_videoRepository extends MongoRepository<val_video ,String> {

    @Query("{ $and:[{'estudiante.nombre':?1},{videourl:?0}]}")
    List<val_video> findByEstudianteAndVideoUrl(String videourl,String name,String value);

    @Query("{ 'dba.Docente.nombre': ?0},{nombre:true}")
    List<val_video> findByDocente(String name, String value);





}
