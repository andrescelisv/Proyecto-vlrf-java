package com.react_java.reactjava.services;

import com.react_java.reactjava.Tarearepository.lvRepository;
import com.react_java.reactjava.Tarearepository.rhuRepository;
import com.react_java.reactjava.commons.GenericServiceException;
import com.react_java.reactjava.commons.ValidateServiceException;
import com.react_java.reactjava.model.Estudiante;
import com.react_java.reactjava.model.LV;
import com.react_java.reactjava.model.ND;
import com.react_java.reactjava.model.RHU;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class lvServices {

    private static final Logger logger = LoggerFactory.getLogger(lvServices.class);

    @Autowired
    private lvRepository LVRepository;

    public List<LV> getAllLV() throws GenericServiceException, ValidateServiceException {
        try {
            List<LV> lv = LVRepository.findAll();
            return lv;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public List<LV> FindByEstudiante(String namestr) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(namestr);
            String id = namestr;

            List<LV> lv = LVRepository.findByEstudiante(id,"hola");
            System.out.println("lv"+ lv);
            return lv;
        } catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public LV getByName(String idstr) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(idstr);
            String id=idstr;
            LV lv1 = LVRepository.findById(id).orElseThrow(RuntimeException::new);
            return lv1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public boolean Verificar(String dba, String estudiante, String docente, String institucion) throws GenericServiceException, ValidateServiceException {
        try {
            List<LV> lv1= LVRepository.findBygradoandgrupoandjornada(dba,estudiante,docente,institucion,"hola");
            System.out.println(lv1);

            List<LV> lv2= LVRepository.findBygradoandgrupoandjornada(dba.toLowerCase(),estudiante.toLowerCase(),docente.toLowerCase(),institucion.toLowerCase(),"hola");
            System.out.println(lv2);

            if(lv1.size() == 0 && lv2.size() != 0 ){
                System.out.println("Existen valores en minuscula");
                return true;
            }

            if(lv1.size() != 0 && lv2.size() == 0) {
                System.out.println("Existen valores en mayúscula");
                return true;
            }
            if(lv1.size() != 0 && lv2.size() != 0) {
                System.out.println("Existen valores en mayúscula");
                return true;
            }
            else if(lv1.size() == 0 && lv2.size() == 0){
                System.out.println("Es igual");
                return false;
            }



        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
        return false;
    }

    public LV saveLV(LV lv) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println("usuario save: "+lv);
            LV lv1 = LVRepository.save(lv);
            return lv1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public LV DeleteLV(LV lv) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println(lv);
            LVRepository.delete(lv);


            return lv;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public String DeleteLVById(String id) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println(id);
            LVRepository.deleteById(id);


            return id;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }


}
