package com.react_java.reactjava.modelDTO;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
public class LV_DTO {

    @NotNull
    private String dba;

    @NotEmpty
    private List<listaVideoDTO> listaVideos;

    @NotNull
    @NotEmpty
    private String fecha;

    @NotEmpty
    @NotNull
    private List<docentesDTO> docente;







}
