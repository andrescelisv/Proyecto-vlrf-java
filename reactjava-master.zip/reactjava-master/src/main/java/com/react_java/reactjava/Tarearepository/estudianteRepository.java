package com.react_java.reactjava.Tarearepository;

import com.react_java.reactjava.model.Docentes;
import com.react_java.reactjava.model.Estudiante;
import com.react_java.reactjava.model.val_video;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface estudianteRepository extends MongoRepository<Estudiante,String> {
    @Query("{ $and:[{nombre:?0},{cedula:?1}]}")
    List<Estudiante> findBynombreAndcedula(String nombre, String cedula, String value);


    @Query("{ 'institucion.nombre': ?0},{nombre:true}")
    List<Estudiante> findByInstitucion(String name, String value);
}
