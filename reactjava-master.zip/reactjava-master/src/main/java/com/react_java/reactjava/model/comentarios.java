package com.react_java.reactjava.model;

import com.react_java.reactjava.modelDTO.DBA_rhuDTO;
import com.react_java.reactjava.modelDTO.comentarioDTO;
import com.react_java.reactjava.modelDTO.estudiantesDTO;
import com.react_java.reactjava.modelDTO.institucionDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@AllArgsConstructor
@Document(collection = "comentarios")
public class comentarios {

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Id
    private String id;

    private List<comentarioDTO> comentario;

    @NotNull
    private List<institucionDTO> institucion;

    private String videourl;










}
