package com.react_java.reactjava.Tarearepository;

import com.react_java.reactjava.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.mongodb.repository.DeleteQuery;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface usuarioRepository extends MongoRepository<User,String> {


    @DeleteQuery
    void deleteById(String id);

}
