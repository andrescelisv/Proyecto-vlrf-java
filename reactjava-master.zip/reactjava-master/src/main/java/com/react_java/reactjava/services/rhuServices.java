package com.react_java.reactjava.services;

import com.react_java.reactjava.Tarearepository.rhuRepository;
import com.react_java.reactjava.Tarearepository.usuarioRepository;
import com.react_java.reactjava.commons.GenericServiceException;
import com.react_java.reactjava.commons.ValidateServiceException;
import com.react_java.reactjava.model.RHU;
import com.react_java.reactjava.model.User;
import com.react_java.reactjava.model.materia;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class rhuServices {

    private static final Logger logger = LoggerFactory.getLogger(rhuServices.class);

    @Autowired
    private rhuRepository RHURepository;

    public List<RHU> getAllRHU() throws GenericServiceException, ValidateServiceException {
        try {
            List<RHU> rhu = RHURepository.findAll();
            return rhu;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public RHU getByName(String idstr) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(idstr);
            String id=idstr;
            RHU rhu1 = RHURepository.findById(id).orElseThrow(RuntimeException::new);
            return rhu1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public boolean Verificar(String fecha, String institucion) throws GenericServiceException, ValidateServiceException {
        try {
            List<RHU> rhu1= RHURepository.findBygradoandgrupoandjornada(fecha,institucion,"hola");
            System.out.println(rhu1);

            List<RHU> rhu2= RHURepository.findBygradoandgrupoandjornada(fecha.toLowerCase(),institucion.toLowerCase(),"hola");
            System.out.println(rhu2);

            if(rhu1.size() == 0 && rhu2.size() != 0 ){
                System.out.println("Existen valores en minuscula");
                return true;
            }

            if(rhu1.size() != 0 && rhu2.size() == 0) {
                System.out.println("Existen valores en mayúscula");
                return true;
            }
            if(rhu1.size() != 0 && rhu2.size() != 0) {
                System.out.println("Existen valores en mayúscula");
                return true;
            }
            else if(rhu1.size() == 0 && rhu2.size() == 0){
                System.out.println("Es igual");
                return false;
            }



        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
        return false;
    }

    public RHU saveRHU(RHU rhu) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println("usuario save: "+rhu);
            RHU rhu1 = RHURepository.save(rhu);
            return rhu1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public RHU DeleteRHU(RHU rhu) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println(rhu);
            RHURepository.delete(rhu);


            return rhu;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public String DeleteRHUById(String id) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println(id);
            RHURepository.deleteById(id);


            return id;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }


}
