package com.react_java.reactjava.Controller;


import com.react_java.reactjava.Tarearepository.TareaRepository;
import com.react_java.reactjava.Tarearepository.docentesRepository;
import com.react_java.reactjava.Tarearepository.gradoRepository;
import com.react_java.reactjava.Tarearepository.materiaRepository;

import com.react_java.reactjava.model.Docentes;
import com.react_java.reactjava.model.Tareas;
import com.react_java.reactjava.model.grado;
import com.react_java.reactjava.modelDTO.materiaDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@CrossOrigin //Habilita para que el cliente angular consulte la API sin ningún error
@RestController
@RequestMapping("/tareas")
public class DocenteController {

    @Autowired
    private TareaRepository tareaRepository;

    @Autowired
    private docentesRepository DocentesRepository;





}
