package com.react_java.reactjava.model;


import com.react_java.reactjava.modelDTO.institucionDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@AllArgsConstructor
@Document(collection = "Grado")
public class grado {


    @Id
    private String id;
    private String grado;
    private String jornada;
    private String grupo;
    private List<institucionDTO> institucion;

    public List<institucionDTO> getInstitución() {
        return institucion;
    }

    public void setInstitución(List<institucionDTO> institucion) {
        this.institucion = institucion;
    }



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGrado() {
        return grado;
    }

    public void setGrado(String grado) {
        this.grado = grado;
    }

    public String getJornada() {
        return jornada;
    }

    public void setJornada(String jornada) {
        this.jornada = jornada;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }





}
