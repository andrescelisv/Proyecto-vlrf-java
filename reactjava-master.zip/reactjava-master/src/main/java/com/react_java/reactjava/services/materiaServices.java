package com.react_java.reactjava.services;

import com.react_java.reactjava.Tarearepository.docentesRepository;
import com.react_java.reactjava.Tarearepository.materiaRepository;
import com.react_java.reactjava.commons.GenericServiceException;
import com.react_java.reactjava.commons.ValidateServiceException;
import com.react_java.reactjava.model.Docentes;
import com.react_java.reactjava.model.grado;
import com.react_java.reactjava.model.materia;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class materiaServices {

    private static final Logger logger = LoggerFactory.getLogger(materiaServices.class);

    @Autowired
    private materiaRepository MateriaRepository;

    public List<materia> getAllMateria() throws GenericServiceException, ValidateServiceException {
        try {
            List<materia> materias = MateriaRepository.findAll();
            return materias;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public List<materia> Name(String namestr) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(namestr);
            String id = namestr;

            List<materia> Materia = MateriaRepository.findByName(id,"hola");
            System.out.println("grado"+ Materia);
            return Materia;
        } catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public boolean Verificar(String area, String nombre, String institucion, String grado) throws GenericServiceException, ValidateServiceException {
        try {
            List<materia> materia1= MateriaRepository.findBygradoandgrupoandjornada(area,nombre,institucion,grado,"hola");
            System.out.println(materia1);

            List<materia> materia2= MateriaRepository.findBygradoandgrupoandjornada(area.toLowerCase(),nombre.toLowerCase(),institucion.toLowerCase(),grado.toLowerCase(),"hola");
            System.out.println(materia2);

            if(materia1.size() == 0 && materia2.size() != 0 ){
                System.out.println("Existen valores en minuscula");
                return true;
            }

            if(materia1.size() != 0 && materia2.size() == 0) {
                System.out.println("Existen valores en mayúscula");
                return true;
            }
            if(materia1.size() != 0 && materia2.size() != 0) {
                System.out.println("Existen valores en mayúscula");
                return true;
            }
            else if(materia1.size() == 0 && materia2.size() == 0){
                System.out.println("Es igual");
                return false;
            }



        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
        return false;
    }

    public materia getByName(String idstr) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(idstr);
            String id=idstr;
            materia materias = MateriaRepository.findById(id).orElseThrow(RuntimeException::new);
            return materias;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public materia saveMateria(materia materias) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(materias);
            materia materias1 = MateriaRepository.save(materias);
            return materias1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public materia DeleteMateria(materia materias) throws GenericServiceException, ValidateServiceException {
        try {

            MateriaRepository.delete(materias);

            return materias;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

}
