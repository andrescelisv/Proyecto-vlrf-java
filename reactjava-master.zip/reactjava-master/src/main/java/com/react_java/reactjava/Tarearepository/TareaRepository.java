package com.react_java.reactjava.Tarearepository;

import com.react_java.reactjava.model.Docentes;
import com.react_java.reactjava.model.Tareas;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface TareaRepository extends MongoRepository<Tareas,String> {


    @Query("{ 'docentes.name':'carlos' }, { docentes:{$elemMatch:{'docentes.1.name':'carlos'}}}")
    List<Docentes> findByDocente();




}
