package com.react_java.reactjava.Tarearepository;

import com.react_java.reactjava.model.RA;
import com.react_java.reactjava.model.RHU;
import com.react_java.reactjava.model.val_video;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface raRepository extends MongoRepository<RA,String> {

    @Query("{$and:[{'estudiante.nombre':?0},{'materia.nombre':?1},{'grado.grado':?2},{'docente.nombre':?3}]}")
    List<RA> findByEstudianteAndRA(String nombreestudiante,String nombremateria,String grado, String nombredocente, String value);

    @Query("{ 'dba.Docente.nombre': ?0},{nombre:true}")
    List<RA> findByDocente(String name, String value);






}
