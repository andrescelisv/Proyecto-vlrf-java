package com.react_java.reactjava.services;

import com.react_java.reactjava.Tarearepository.raRepository;
import com.react_java.reactjava.Tarearepository.rhuRepository;
import com.react_java.reactjava.commons.GenericServiceException;
import com.react_java.reactjava.commons.ValidateServiceException;
import com.react_java.reactjava.model.RA;
import com.react_java.reactjava.model.RHU;
import com.react_java.reactjava.model.val_video;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class raServices {

    private static final Logger logger = LoggerFactory.getLogger(raServices.class);

    @Autowired
    private raRepository RARepository;

    public List<RA> getAllRA() throws GenericServiceException, ValidateServiceException {
        try {
            List<RA> ra = RARepository.findAll();
            return ra;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public RA getByName(String idstr) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(idstr);
            String id=idstr;
            RA ra1 = RARepository.findById(id).orElseThrow(RuntimeException::new);
            return ra1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public boolean Verificar(String nombreEstudiante, String nombremateria,String grado, String nombredocente) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println(nombreEstudiante+":"+nombremateria+":"+nombredocente+":"+grado);
            System.out.println(nombreEstudiante.contains("/"));

            List<RA> ra1= RARepository.findByEstudianteAndRA(nombreEstudiante,nombremateria,grado,nombredocente,"hola");
            System.out.println(ra1);

            if(ra1.size() == 0 ){
                System.out.println("No existen estos valores");
                return false;
            }
            else{
                System.out.println("Es igual");
                return true;
            }



        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public RA getBydbaMateriandGrado(String materia,String grado) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(materia);
            System.out.println(grado);
            RA ra1 = RARepository.findById(materia).orElseThrow(RuntimeException::new);
            return ra1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }


    public RA saveRA(RA ra) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println("usuario save: "+ra);
            RA ra1 = RARepository.save(ra);
            return ra1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public RA DeleteRA(RA ra) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println(ra);
            RARepository.delete(ra);


            return ra;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public String DeleteRAById(String id) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println(id);
            RARepository.deleteById(id);


            return id;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }


}
