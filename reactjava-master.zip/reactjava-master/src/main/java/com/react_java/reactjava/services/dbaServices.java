package com.react_java.reactjava.services;

import com.react_java.reactjava.Tarearepository.dbaRepository;
import com.react_java.reactjava.Tarearepository.rhuRepository;
import com.react_java.reactjava.commons.GenericServiceException;
import com.react_java.reactjava.commons.ValidateServiceException;
import com.react_java.reactjava.model.RHU;
import com.react_java.reactjava.model.dba;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class dbaServices {

    private static final Logger logger = LoggerFactory.getLogger(dbaServices.class);

    @Autowired
    private dbaRepository DBARepository;



    public List<dba> getAllDBA() throws GenericServiceException, ValidateServiceException {
        try {
            List<dba> dba1 = DBARepository.findAll();
            return dba1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public dba getByName(String idstr) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(idstr);
            String id=idstr;
            dba dba1 = DBARepository.findById(id).orElseThrow(RuntimeException::new);
            return dba1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public dba saveDBA(dba dba1) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println("usuario save: "+dba1);
            dba dba2 = DBARepository.save(dba1);
            return dba2;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public dba DeleteDBA(dba dba1) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println(dba1);
            DBARepository.delete(dba1);


            return dba1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public String DeleteDBAById(String id) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println(id);
            DBARepository.deleteById(id);


            return id;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }


}
