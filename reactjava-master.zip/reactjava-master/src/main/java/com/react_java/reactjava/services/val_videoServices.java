package com.react_java.reactjava.services;

import com.react_java.reactjava.Tarearepository.lvRepository;
import com.react_java.reactjava.Tarearepository.val_videoRepository;
import com.react_java.reactjava.commons.GenericServiceException;
import com.react_java.reactjava.commons.ValidateServiceException;
import com.react_java.reactjava.model.LV;
import com.react_java.reactjava.model.val_video;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class val_videoServices {

    private static final Logger logger = LoggerFactory.getLogger(val_videoServices.class);

    @Autowired
    private val_videoRepository Val_VideoRepository;

    public List<val_video> getAllval_video() throws GenericServiceException, ValidateServiceException {
        try {
            List<val_video> val_video1 = Val_VideoRepository.findAll();
            return val_video1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public List<val_video> FindByval_video(String namestr) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(namestr);
            String id = namestr;

            List<val_video> val_video1= Val_VideoRepository.findByDocente(id,"hola");
            System.out.println("lv"+ val_video1);
            return val_video1;
        } catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public val_video getByName(String idstr) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(idstr);
            String id=idstr;
            val_video val_video1 = Val_VideoRepository.findById(id).orElseThrow(RuntimeException::new);
            return val_video1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public val_video saveValVideo(val_video val_video1) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println("usuario save: "+val_video1);
            val_video valvideo1 = Val_VideoRepository.save(val_video1);
            return val_video1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public boolean Verificar(String videoUrl, String name) throws GenericServiceException, ValidateServiceException {
        try {
            List<val_video> val_video1= Val_VideoRepository.findByEstudianteAndVideoUrl(videoUrl,name,"hola");
             System.out.println(val_video1);

            if(val_video1.size() == 0 ){
                System.out.println("No existen estos valores");
                return false;
            }
            else{
                System.out.println("Es igual");
                return true;
            }



        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public val_video DeleteValVideo(val_video valvideo1) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println(valvideo1);
            Val_VideoRepository.delete(valvideo1);


            return valvideo1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public String DeleteLVal_VideoById(String id) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println(id);
            Val_VideoRepository.deleteById(id);


            return id;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }


}
