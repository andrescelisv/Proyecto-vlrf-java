package com.react_java.reactjava.model;

import com.react_java.reactjava.modelDTO.DBA_rhuDTO;
import com.react_java.reactjava.modelDTO.estudiantesDTO;
import com.react_java.reactjava.modelDTO.gradoDTO;
import com.react_java.reactjava.modelDTO.institucionDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


import java.util.List;

@Data
@AllArgsConstructor
@Document(collection = "RHU")
public class RHU {

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Id
    private String id;

    private List<DBA_rhuDTO> dba;

    private List<estudiantesDTO> estudiante;
    private List<institucionDTO> institucion;

    public List<DBA_rhuDTO> getDba() {
        return dba;
    }

    public void setDba(List<DBA_rhuDTO> dba) {
        this.dba = dba;
    }



    public List<estudiantesDTO> getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(List<estudiantesDTO> estudiante) {
        this.estudiante = estudiante;
    }
















}
