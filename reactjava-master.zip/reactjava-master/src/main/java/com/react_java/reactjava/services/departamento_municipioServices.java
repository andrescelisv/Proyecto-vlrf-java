package com.react_java.reactjava.services;

import com.react_java.reactjava.Tarearepository.Departamento_municipioRepository;
import com.react_java.reactjava.Tarearepository.institucionRepository;
import com.react_java.reactjava.commons.GenericServiceException;
import com.react_java.reactjava.commons.ValidateServiceException;
import com.react_java.reactjava.model.Departamento_municipio;
import com.react_java.reactjava.model.institucion;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class departamento_municipioServices {

    private static final Logger logger = LoggerFactory.getLogger(departamento_municipioServices.class);

    @Autowired
    private Departamento_municipioRepository departamento_municipioRepository;

    public List<Departamento_municipio> getQueryDepartamento(String namestr) throws GenericServiceException, ValidateServiceException {
        try {
            List<Departamento_municipio> departamento_municipio = departamento_municipioRepository.findByDepartamento(namestr,"hola");
            return departamento_municipio;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }



}
