package com.react_java.reactjava.model;

import com.react_java.reactjava.modelDTO.LV_DTO;
import com.react_java.reactjava.modelDTO.estudiantesDTO;
import com.react_java.reactjava.modelDTO.institucionDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@AllArgsConstructor
@Document(collection = "val_video")
public class val_video {

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Id
    private String id;

    @NotNull
    @NotEmpty
    private String val;

    @NotNull
    @NotEmpty
    private String videourl;

    @NotNull
    private List<estudiantesDTO> estudiante;

    @NotNull
    private List<institucionDTO> institucion;


















}
