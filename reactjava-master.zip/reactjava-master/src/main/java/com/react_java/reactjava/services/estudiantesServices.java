package com.react_java.reactjava.services;

import com.react_java.reactjava.Tarearepository.estudianteRepository;
import com.react_java.reactjava.commons.GenericServiceException;
import com.react_java.reactjava.commons.ValidateServiceException;
import com.react_java.reactjava.model.Docentes;
import com.react_java.reactjava.model.Estudiante;
import com.react_java.reactjava.model.val_video;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class estudiantesServices {

    private static final Logger logger = LoggerFactory.getLogger(estudiantesServices.class);

    @Autowired
    private estudianteRepository EstudianteRepository;

    public List<Estudiante> getAllEstudiantes() throws GenericServiceException, ValidateServiceException {
        try {
            List<Estudiante> estudiantes = EstudianteRepository.findAll();
            return estudiantes;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public Estudiante getByName(String idstr) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(idstr);
            String id=idstr;
            Estudiante estudiantes = EstudianteRepository.findById(id).orElseThrow(RuntimeException::new);
            return estudiantes;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public boolean Verificar(String nombre, String cedula) throws GenericServiceException, ValidateServiceException {
        try {
            List<Estudiante> estudiante1= EstudianteRepository.findBynombreAndcedula(nombre,cedula,"hola");
            List<Estudiante> estudiante2= EstudianteRepository.findBynombreAndcedula(nombre.toLowerCase(),cedula,"hola");
            System.out.println(estudiante1);
            System.out.println(estudiante2);
            if(estudiante1.size() == 0 && estudiante2.size() != 0 ){
                System.out.println("Existen valores en minuscula");
                return true;
            }

            if(estudiante1.size() != 0 && estudiante2.size() == 0) {
                System.out.println("Existen valores en mayúscula");
                return true;
            }
            if(estudiante1.size() != 0 && estudiante2.size() != 0) {
                System.out.println("Existen valores en mayúscula");
                return true;
            }
            else if(estudiante1.size() == 0 && estudiante2.size() == 0){
                System.out.println("Es igual");
                return false;
            }



        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
        return false;
    }

    public List<Estudiante> FindByInstitucion(String namestr) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(namestr);
            String id = namestr;

            List<Estudiante> Estudiantes = EstudianteRepository.findByInstitucion(id,"hola");
            System.out.println("grado"+ Estudiantes);
            return Estudiantes;
        } catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public Estudiante saveEstudiante(Estudiante estudiante) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(estudiante);
            Estudiante estudiantes = EstudianteRepository.save(estudiante);
            return estudiantes;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public Estudiante DeleteEstudiante(Estudiante estudiante) throws GenericServiceException, ValidateServiceException {
        try {

            EstudianteRepository.delete(estudiante);

            return estudiante;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

}
