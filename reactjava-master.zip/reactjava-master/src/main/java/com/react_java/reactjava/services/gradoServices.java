package com.react_java.reactjava.services;

import com.react_java.reactjava.Tarearepository.estudianteRepository;
import com.react_java.reactjava.Tarearepository.gradoRepository;
import com.react_java.reactjava.commons.GenericServiceException;
import com.react_java.reactjava.commons.ValidateServiceException;
import com.react_java.reactjava.model.Docentes;
import com.react_java.reactjava.model.Estudiante;
import com.react_java.reactjava.model.grado;
import com.react_java.reactjava.model.val_video;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Locale;

@Service
public class gradoServices {

    private static final Logger logger = LoggerFactory.getLogger(gradoServices.class);

    @Autowired
    private gradoRepository GradoRepository;

    public List<grado> getAllGrados() throws GenericServiceException, ValidateServiceException {
        try {
            List<grado> Grado = GradoRepository.findAll();
            return Grado;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public List<grado> Name(String namestr) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(namestr);
            String id = namestr;

            List<grado> Grado = GradoRepository.findByName(id,"hola");
            System.out.println("grado"+ Grado);
            return Grado;
        } catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

        public grado getByName(String idstr) throws GenericServiceException, ValidateServiceException {
            try {
                System.out.println("llego id");
                System.out.println(idstr);
                String id=idstr;
                grado Grados = GradoRepository.findById(id).orElseThrow(RuntimeException::new);
                return Grados;
            }catch (Exception e) {
                throw new GenericServiceException("Internal Server Error");
            }
        }


    public grado getById(String idstr) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(idstr);
            String id=idstr;
            grado Grado = GradoRepository.findById(id).orElseThrow(RuntimeException::new);
            return Grado;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public boolean Verificar(String grado, String jornada, String grupo, String institucion) throws GenericServiceException, ValidateServiceException {
        try {
            List<grado> grado1= GradoRepository.findBygradoandgrupoandjornada(grado,jornada,grupo,institucion,"hola");
            System.out.println(grado1);

            List<grado> grado2= GradoRepository.findBygradoandgrupoandjornada(grado.toLowerCase(),jornada.toLowerCase(),grupo.toLowerCase(),institucion.toLowerCase(),"hola");
            System.out.println(grado1);

            if(grado1.size() == 0 && grado2.size() != 0 ){
                System.out.println("Existen valores en minuscula");
                return true;
            }

            if(grado1.size() != 0 && grado2.size() == 0) {
                System.out.println("Existen valores en mayúscula");
                return true;
            }
            if(grado1.size() != 0 && grado2.size() != 0) {
                System.out.println("Existen valores en mayúscula");
                return true;
            }
            else if(grado1.size() == 0 && grado2.size() == 0){
                System.out.println("Es igual");
                return false;
            }



        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
        return false;
    }

    public grado saveEstudiante(grado Grado) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(Grado);
            grado Gradore = GradoRepository.save(Grado);
            return Gradore;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public grado DeleteEstudiante(grado Grado) throws GenericServiceException, ValidateServiceException {
        try {

            GradoRepository.delete(Grado);

            return Grado;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

}
