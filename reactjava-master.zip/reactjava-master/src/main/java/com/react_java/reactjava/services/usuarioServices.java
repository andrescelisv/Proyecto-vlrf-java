package com.react_java.reactjava.services;

import com.react_java.reactjava.Tarearepository.materiaRepository;
import com.react_java.reactjava.Tarearepository.usuarioRepository;
import com.react_java.reactjava.commons.GenericServiceException;
import com.react_java.reactjava.commons.ValidateServiceException;
import com.react_java.reactjava.model.User;
import com.react_java.reactjava.model.materia;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class usuarioServices {

    private static final Logger logger = LoggerFactory.getLogger(materiaServices.class);

    @Autowired
    private usuarioRepository UsuarioRepository;

    public List<User> getAllUser() throws GenericServiceException, ValidateServiceException {
        try {
            List<User> usuario1 = UsuarioRepository.findAll();
            return usuario1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public User getByName(String idstr) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(idstr);
            String id=idstr;
            User usuario1 = UsuarioRepository.findById(id).orElseThrow(RuntimeException::new);
            return usuario1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public User saveUser(User usuario) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println("usuario save: "+usuario);
            User usuario1 = UsuarioRepository.save(usuario);
            return usuario1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public User DeleteUser(User usuario) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println(usuario);
            UsuarioRepository.delete(usuario);


            return usuario;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public String DeleteUserById(String id) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println(id);
            UsuarioRepository.deleteById(id);


            return id;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }


}
