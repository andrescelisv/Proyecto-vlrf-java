package com.react_java.reactjava.Tarearepository;

import com.react_java.reactjava.model.LV;
import com.react_java.reactjava.model.ND;
import com.react_java.reactjava.model.RHU;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface lvRepository extends MongoRepository<LV,String> {

    @Query("{ $and:[{'lv.dba':?0},{'estudiante.nombre':?1},{'institucion.nombre':?3}]}")
    List<LV> findBygradoandgrupoandjornada(String dba, String estudiante, String docente, String institucion, String value);



    @Query("{ 'estudiante.nombre': 'andres fernando celis velez'},{estudiante:true}")
    List<LV> findByEstudiante(String name, String value);






}
