package com.react_java.reactjava.services;

import com.react_java.reactjava.Tarearepository.ndRepository;
import com.react_java.reactjava.Tarearepository.rhuRepository;
import com.react_java.reactjava.commons.GenericServiceException;
import com.react_java.reactjava.commons.ValidateServiceException;
import com.react_java.reactjava.model.ND;
import com.react_java.reactjava.model.RHU;
import com.react_java.reactjava.model.materia;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ndServices {

    private static final Logger logger = LoggerFactory.getLogger(ndServices.class);

    @Autowired
    private ndRepository NDRepository;

    public List<ND> getAllND() throws GenericServiceException, ValidateServiceException {
        try {
            List<ND> nd = NDRepository.findAll();
            return nd;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public ND getByName(String idstr) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(idstr);
            String id=idstr;
            ND nd1 = NDRepository.findById(id).orElseThrow(RuntimeException::new);
            return nd1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }
    public boolean Verificar(String dba, String estudiante, String docente, String institucion) throws GenericServiceException, ValidateServiceException {
        try {
            List<ND> nd1= NDRepository.findBygradoandgrupoandjornada(dba,estudiante,docente,institucion,"hola");
            System.out.println(nd1);

            List<ND> nd2= NDRepository.findBygradoandgrupoandjornada(dba.toLowerCase(),estudiante.toLowerCase(),docente.toLowerCase(),institucion.toLowerCase(),"hola");
            System.out.println(nd2);

            if(nd1.size() == 0 && nd2.size() != 0 ){
                System.out.println("Existen valores en minuscula");
                return true;
            }

            if(nd1.size() != 0 && nd2.size() == 0) {
                System.out.println("Existen valores en mayúscula");
                return true;
            }
            if(nd1.size() != 0 && nd2.size() != 0) {
                System.out.println("Existen valores en mayúscula");
                return true;
            }
            else if(nd1.size() == 0 && nd2.size() == 0){
                System.out.println("Es igual");
                return false;
            }



        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
        return false;
    }


    public ND saveND(ND nd) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println("usuario save: "+nd);
            ND nd1 = NDRepository.save(nd);
            return nd1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public ND DeleteND(ND nd) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println(nd);
            NDRepository.delete(nd);


            return nd;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public String DeleteNDById(String id) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println(id);
            NDRepository.deleteById(id);


            return id;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }


}
