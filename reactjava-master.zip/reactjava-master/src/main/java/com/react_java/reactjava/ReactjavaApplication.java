package com.react_java.reactjava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactjavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactjavaApplication.class, args);
	}

}
