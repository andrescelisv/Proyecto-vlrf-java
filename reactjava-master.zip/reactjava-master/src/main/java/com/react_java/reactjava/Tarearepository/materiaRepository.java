package com.react_java.reactjava.Tarearepository;

import com.react_java.reactjava.model.grado;
import com.react_java.reactjava.model.materia;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface materiaRepository extends MongoRepository<materia,String> {

    @Query("{ $and:[{'institucion.nombre':?2},{'grado.grado':?3},{area:?0},{nombre:?1}]}")
    List<materia> findBygradoandgrupoandjornada(String area,String nombre,String institucion,String grado,String value);


    @Query("{ 'institucion.nombre': ?0},{nombre:true}")
    List<materia> findByName(String name, String value);

}
