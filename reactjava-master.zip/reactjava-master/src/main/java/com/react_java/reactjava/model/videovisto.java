package com.react_java.reactjava.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
public class videovisto {

    public String getVideovisto() {
        return videovisto;
    }

    public void setVideovisto(String videovisto) {
        this.videovisto = videovisto;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    private String videovisto;
    private String fecha;




}
