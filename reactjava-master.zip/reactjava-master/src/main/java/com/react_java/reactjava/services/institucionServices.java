package com.react_java.reactjava.services;

import com.react_java.reactjava.Tarearepository.docentesRepository;
import com.react_java.reactjava.Tarearepository.institucionRepository;
import com.react_java.reactjava.commons.GenericServiceException;
import com.react_java.reactjava.commons.ValidateServiceException;
import com.react_java.reactjava.model.Docentes;
import com.react_java.reactjava.model.grado;
import com.react_java.reactjava.model.institucion;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class institucionServices {

    private static final Logger logger = LoggerFactory.getLogger(institucionServices.class);

    @Autowired
    private institucionRepository InstitucionRepository;

    public List<institucion> getAllInstitucion() throws GenericServiceException, ValidateServiceException {
        try {
            List<institucion> instituciones = InstitucionRepository.findAll();
            return instituciones;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public institucion getByName(String idstr) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(idstr);
            String id=idstr;
            institucion instituciones = InstitucionRepository.findById(id).orElseThrow(RuntimeException::new);
            return instituciones;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public boolean Verificar(String nombre, String departamento, String municipio, String zona) throws GenericServiceException, ValidateServiceException {
        try {
            List<com.react_java.reactjava.model.grado> institucion1= InstitucionRepository.findBygradoandgrupoandjornada(nombre,departamento,municipio,zona,"hola");
            System.out.println(institucion1);

            List<grado> institucion2= InstitucionRepository.findBygradoandgrupoandjornada(nombre.toLowerCase(),departamento.toLowerCase(),municipio.toLowerCase(),zona.toLowerCase(),"hola");
            System.out.println(institucion2);

            if(institucion1.size() == 0 && institucion2.size() != 0 ){
                System.out.println("Existen valores en minuscula");
                return true;
            }

            if(institucion1.size() != 0 && institucion2.size() == 0) {
                System.out.println("Existen valores en mayúscula");
                return true;
            }
            if(institucion1.size() != 0 && institucion2.size() != 0) {
                System.out.println("Existen valores en mayúscula");
                return true;
            }
            else if(institucion1.size() == 0 && institucion2.size() == 0){
                System.out.println("Es igual");
                return false;
            }



        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
        return false;
    }

    public institucion saveInstitucion(institucion instituciones) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(instituciones);
            institucion institucion1 = InstitucionRepository.save(instituciones);
            return institucion1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public institucion DeleteInstitucion(institucion instituciones) throws GenericServiceException, ValidateServiceException {
        try {

            InstitucionRepository.delete(instituciones);

            return instituciones;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

}
