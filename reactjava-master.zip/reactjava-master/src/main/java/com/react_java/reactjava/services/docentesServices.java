package com.react_java.reactjava.services;

import com.react_java.reactjava.Tarearepository.docentesRepository;
import com.react_java.reactjava.Tarearepository.estudianteRepository;
import com.react_java.reactjava.Tarearepository.gradoRepository;
import com.react_java.reactjava.commons.GenericServiceException;
import com.react_java.reactjava.commons.ValidateServiceException;
import com.react_java.reactjava.model.Docentes;
import com.react_java.reactjava.model.Estudiante;
import com.react_java.reactjava.model.grado;
import com.react_java.reactjava.model.materia;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.print.Doc;
import java.util.List;

@Service
public class docentesServices {

    private static final Logger logger = LoggerFactory.getLogger(docentesServices.class);

    @Autowired
    private docentesRepository DocentesRepository;

    public List<Docentes> getAllDocentes() throws GenericServiceException, ValidateServiceException {
        try {
            List<Docentes> docentes = DocentesRepository.findAll();
            return docentes;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public List<Docentes> FindByInstitucion(String namestr) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(namestr);
            String id = namestr;

            List<Docentes> Docente = DocentesRepository.findByInstitucion(id,"hola");
            System.out.println("grado"+ Docente);
            return Docente;
        } catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public Docentes getByName(String idstr) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");
            System.out.println(idstr);
            String id=idstr;
            Docentes docentes = DocentesRepository.findById(id).orElseThrow(RuntimeException::new);
            return docentes;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public boolean Verificar(String nombre, String cedula) throws GenericServiceException, ValidateServiceException {
        try {
            List<Docentes> docente1= DocentesRepository.findBynombreAndcedula(nombre,cedula,"hola");
            List<Docentes> docente2= DocentesRepository.findBynombreAndcedula(nombre.toLowerCase(),cedula,"hola");


            System.out.println(docente1);
            System.out.println(docente2);
            if(docente1.size() != 0 && docente2.size() == 0 ){
                System.out.println("Existen valores en minuscula");
                return true;
            }

            if(docente1.size() == 0 && docente2.size() != 0) {
                System.out.println("Existen valores en mayúscula");
                return true;
            }
            if(docente1.size() != 0 && docente2.size() != 0) {
                System.out.println("Existen valores en mayúscula");
                return true;
            }
            else if(docente1.size() == 0 && docente2.size() == 0){
                System.out.println("No son iguales");
                return false;
            }



        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
        return false;
    }

    public Docentes saveDocente(Docentes docentes) throws GenericServiceException, ValidateServiceException {
        try {
            System.out.println("llego id");

            Docentes docentes1 = DocentesRepository.save(docentes);
            System.out.println("docentes: "+docentes1);
            return docentes1;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

    public Docentes DeleteDocente(Docentes docentes) throws GenericServiceException, ValidateServiceException {
        try {

            DocentesRepository.delete(docentes);

            return docentes;
        }catch (Exception e) {
            throw new GenericServiceException("Internal Server Error");
        }
    }

}
