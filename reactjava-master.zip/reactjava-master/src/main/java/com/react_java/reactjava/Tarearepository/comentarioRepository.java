package com.react_java.reactjava.Tarearepository;

import com.react_java.reactjava.model.RA;
import com.react_java.reactjava.model.RHU;
import com.react_java.reactjava.model.comentarios;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface comentarioRepository extends MongoRepository<comentarios,String> {
    @Query("{$and:[{'estudiante.nombre':?0},{'materia.nombre':?1},{'grado.grado':?2},{'docente.nombre':?3}]}")
    List<comentarios> findByEstudianteAndRA(String nombreestudiante, String nombremateria, String grado, String nombredocente, String value);


    @Query("{ 'dba.Docente.nombre': ?0},{nombre:true}")
    List<comentarios> findByDocente(String name, String value);






}
