package com.react_java.reactjava.utils;

import org.apache.jena.atlas.logging.LogCtl;
import org.apache.jena.base.Sys;
import org.apache.jena.query.*;
import org.apache.jena.rdf.model.*;
import org.apache.jena.rdfconnection.RDFConnection;
import org.apache.jena.riot.RDFDataMgr;
import org.apache.jena.riot.RDFFormat;
import org.apache.jena.sparql.core.DatasetGraph;
import org.apache.jena.tdb.TDBFactory;
import org.apache.jena.tdb2.TDB2Factory;
import org.apache.jena.vocabulary.DC_11;
import org.apache.jena.vocabulary.VCARD;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

public class jenaSparql extends Object{

   private List<String> dba;
   public Dataset dataset;


    public jenaSparql(){
        this.dataset = TDB2Factory.connectDataset("C:\\Apache24\\htdocs\\mvcframe\\modelo\\archivonewejemplo");
        System.out.println("dataset:     "+this.dataset.toString());
       /* try ( RDFConnection conn = RDFConnection.connect(dataset)) {
            conn.load("C:\\Apache24\\htdocs\\mvcframe\\modelo\\archivonewejemplo.xml") ;
            conn.querySelect("SELECT DISTINCT ?s ?sr { ?s ?p ?o }", (qs) -> {

                System.out.println("Subject: " + qs) ;
            }) ;
        }*/

    }

    public List<String> videoResourceKeyword(String palabra){

        LogCtl.setCmdLogging();
         System.out.println(palabra);







        // Dataset ds = DatasetFactory.createTxnMem() ;

        // Create a new query
        String queryStringVideoResourceKeyword =
                "PREFIX vlrf: <http://www.semanticweb.org/VLRF/VLRF_KB#> " +
                        "# PREFIX bif: <http://www.openlinksw.com/schemas/bif#> \r\n"
                        + "# PREFIX bif: <http://www.openlinksw.com/schema/sparql/extensions#> \r\n"
                        + "# PREFIX bif: <http://virtuoso.openlinksw.com/data/turtle/general/VirtuosoBIFFunctions#> \r\n"
                        + "# PREFIX bif: <http://www.openlinksw.com/schema/sparql/extensions#bif> \r\n"
                        + "PREFIX bif: <bif:>   "+
                        "SELECT ?video " +
                        "WHERE {" +
                        "      ?video vlrf:VideoResourceKeyword ?palabra." + "FILTER (regex(?palabra,'"+palabra+"','i')) ."+
                        "      }";

        this.dataset.begin(ReadWrite.WRITE);
        Query query = QueryFactory.create(queryStringVideoResourceKeyword);

        // Execute the query and obtain results

        QueryExecution qe = QueryExecutionFactory.create(query, this.dataset);

        ResultSet results = qe.execSelect();







        // write to a ByteArrayOutputStream
        //ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        List<QuerySolution> valor = ResultSetFormatter.toList(results);
        qe.close();
        List<String> arreglo = new ArrayList<String>();
        for(int i=0;i<valor.size();i++) {
            System.out.println(valor.get(i).toString());
            arreglo.add(valor.get(i).toString().replace(">", "").replace(")", "").substring(valor.get(i).toString().indexOf("#")+1));
        }

        System.out.println(arreglo);
        // and turn that into a String
        //String json = new String(outputStream.toByteArray());

        //System.out.println(json);


        // Important ‑ free up resources used running the query

        this.dataset.abort();
        this.dataset.close();
        this.dataset.end();
        return arreglo;
    }

    public List<String> dba(String materia,String grado){

        LogCtl.setCmdLogging();
        System.out.println(grado);
        grado = convertir(grado);

        String referencia= ReferenciaRDF(materia,grado);


        System.out.println(referencia);


        // Dataset ds = DatasetFactory.createTxnMem() ;

        // Create a new query
        String queryStringDBA =
                "PREFIX vlrf: <http://www.semanticweb.org/VLRF/VLRF_KB#> " +
                        "# PREFIX bif: <http://www.openlinksw.com/schemas/bif#> \r\n"
                        + "# PREFIX bif: <http://www.openlinksw.com/schema/sparql/extensions#> \r\n"
                        + "# PREFIX bif: <http://virtuoso.openlinksw.com/data/turtle/general/VirtuosoBIFFunctions#> \r\n"
                        + "# PREFIX bif: <http://www.openlinksw.com/schema/sparql/extensions#bif> \r\n"
                        + "PREFIX bif: <bif:>   "+
                        "SELECT ?video " +
                        "WHERE {" +
                        "      ?video vlrf:CompetencyId ?palabra." + "FILTER (regex(?palabra,'"+referencia+"','i')) ."+
                        "      }";

        this.dataset.begin(ReadWrite.WRITE);
        Query query = QueryFactory.create(queryStringDBA);

        // Execute the query and obtain results

        QueryExecution qe = QueryExecutionFactory.create(query, this.dataset);

        ResultSet results = qe.execSelect();







        // write to a ByteArrayOutputStream
        //ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        List<QuerySolution> valor = ResultSetFormatter.toList(results);
        qe.close();
        List<String> arreglo = new ArrayList<String>();
        for(int i=0;i<valor.size();i++) {
            System.out.println(valor.get(i).toString());
            arreglo.add(valor.get(i).toString().replace(">", "").replace(")", "").substring(valor.get(i).toString().indexOf("#")+1));
        }

        System.out.println(arreglo);
        // and turn that into a String
        //String json = new String(outputStream.toByteArray());

        //System.out.println(json);


        // Important ‑ free up resources used running the query

        this.dataset.abort();
        this.dataset.close();
        this.dataset.end();
        return arreglo;
    }

    public String convertir(String numerotexto){
        switch (numerotexto){
            case "Primero":
                return "1";
            case "Segundo":
                return "2";
            case "Tercero":
                return "3";
            case "Cuarto":
                return "4";
            case "Quinto":
                return "5";
            case "Sexto":
                return "6";
            case "Septimo":
                return "7";
            case "Octavo":
                return "8";
            case "Noveno":
                return "9";
            case "Decimo":
                return "10";
            case "Undecimo":
                return "11";
            default:
                return " ";
        }



    }


    public String ReferenciaRDF(String materia,String Grado){

     materia = materia.toUpperCase().substring(0,3);
     String cadena = "VLRFCO"+materia+Grado;

    return cadena;

    }


}
