package com.react_java.reactjava.Tarearepository;

import com.react_java.reactjava.model.Docentes;
import com.react_java.reactjava.model.RHU;
import com.react_java.reactjava.model.materia;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface rhuRepository extends MongoRepository<RHU,String> {

    @Query("{{'dba.fecha':?0}}")
    List<RHU> findBygradoandgrupoandjornada(String fecha,String institucion,String value);


    @Query("{ 'dba.Docente.nombre': ?0},{nombre:true}")
    List<RHU> findByDocente(String name, String value);






}
