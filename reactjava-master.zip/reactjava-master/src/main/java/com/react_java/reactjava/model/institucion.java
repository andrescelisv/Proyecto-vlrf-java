package com.react_java.reactjava.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "institucion")
public class institucion {


    @Id
    private String id;
    private String nombre;
    private String correoElectronico;
    private String ubicacion;
    private String municipio;
    private String departamento;
    private String telefono;
    private String zona;
    private String jornada;



}
