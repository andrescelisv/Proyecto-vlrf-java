package com.react_java.reactjava.Tarearepository;

import com.react_java.reactjava.model.Docentes;
import com.react_java.reactjava.model.grado;
import com.react_java.reactjava.model.materia;
import com.react_java.reactjava.model.val_video;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface gradoRepository extends MongoRepository<grado,String> {
    @Query("{ $and:[{'institucion.nombre':?3},{grado:?0},{grupo:?2},{jornada:?1}]}")
    List<grado> findBygradoandgrupoandjornada(String grado,String jornada,String grupo,String institucion,String value);

    @Query("{ 'institucion.nombre': ?0},{grado:true,jornada:true,grupo:true}")
    List<grado> findByName(String name,String value);

}
