package com.react_java.reactjava.model;

import com.react_java.reactjava.modelDTO.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@AllArgsConstructor
@Document(collection = "RA")
public class RA {
        @Id
        private String id;
        private List<listaDBADTO> dba;
        private String fecha;
        private List<docentesDTO> docente;
        private List<estudiantesDTO> estudiante;
        private List<institucionDTO> institucion;
        private List<gradoDTO> grado;
        private List<materiaDTO> materia;

}
