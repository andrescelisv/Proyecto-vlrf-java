package com.react_java.reactjava.Tarearepository;

import com.react_java.reactjava.model.Docentes;
import com.react_java.reactjava.model.Tareas;
import com.react_java.reactjava.model.dba;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface dbaRepository extends MongoRepository<dba,String> {







}
