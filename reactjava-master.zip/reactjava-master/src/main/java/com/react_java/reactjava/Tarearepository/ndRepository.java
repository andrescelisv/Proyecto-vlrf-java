package com.react_java.reactjava.Tarearepository;

import com.react_java.reactjava.model.ND;
import com.react_java.reactjava.model.RHU;
import com.react_java.reactjava.model.materia;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface ndRepository extends MongoRepository<ND,String> {

    @Query("{ $and:[{'nd.dba':?0},{'estudiante.nombre':?1},{'institucion.nombre':?3}]}")
    List<ND> findBygradoandgrupoandjornada(String dba, String estudiante, String docente, String institucion, String value);


    @Query("{ 'dba.Docente.nombre': ?0},{nombre:true}")
    List<ND> findByDocente(String name, String value);






}
