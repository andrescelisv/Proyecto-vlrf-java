package com.react_java.reactjava.modelDTO;

import lombok.Data;
import org.springframework.data.annotation.Id;

@Data
public class departamento_municipioDTO {

    private String region;
    private String departamento;
    private String municipio;

}
