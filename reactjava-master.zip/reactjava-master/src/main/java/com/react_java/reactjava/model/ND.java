package com.react_java.reactjava.model;

import com.react_java.reactjava.modelDTO.DBA_rhuDTO;
import com.react_java.reactjava.modelDTO.ND_DTO;
import com.react_java.reactjava.modelDTO.estudiantesDTO;
import com.react_java.reactjava.modelDTO.institucionDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@AllArgsConstructor
@Document(collection = "ND")
public class ND {

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Id
    private String id;

    @NotNull
    private List<ND_DTO> nd;

    @NotNull
    private List<estudiantesDTO> estudiante;

    @NotNull
    private List<institucionDTO> institucion;

    public List<ND_DTO> getNd() {
        return nd;
    }

    public void setNd(List<ND_DTO> nd) {
        this.nd = nd;
    }

    public List<estudiantesDTO> getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(List<estudiantesDTO> estudiante) {
        this.estudiante = estudiante;
    }

    public List<institucionDTO> getInstitucion() {
        return institucion;
    }

    public void setInstitucion(List<institucionDTO> institucion) {
        this.institucion = institucion;
    }


















}
