package com.react_java.reactjava.Tarearepository;

import com.react_java.reactjava.model.Departamento_municipio;
import com.react_java.reactjava.model.Docentes;
import com.react_java.reactjava.model.institucion;
import com.react_java.reactjava.model.materia;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface Departamento_municipioRepository extends MongoRepository<Departamento_municipio,String> {

    @Query("{ departamento: ?0},{nombre:true}")
    List<Departamento_municipio> findByDepartamento(String name, String value);
}
