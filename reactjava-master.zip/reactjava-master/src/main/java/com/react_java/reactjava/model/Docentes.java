package com.react_java.reactjava.model;

import com.react_java.reactjava.modelDTO.gradoDTO;
import com.react_java.reactjava.modelDTO.institucionDTO;
import com.react_java.reactjava.modelDTO.materiaDTO;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@Document(collection = "Docente")

public class Docentes {
    @Id
    private String id;
    private String nombre;
    private String correoElectronico;
    private String fechaNacimiento;
    private String cedula;
    private List<institucionDTO> institucion;
    private List<gradoDTO> Grado;
    private List<materiaDTO> Materia;
}