package com.react_java.reactjava.Controller;

public class AuthController {

}
