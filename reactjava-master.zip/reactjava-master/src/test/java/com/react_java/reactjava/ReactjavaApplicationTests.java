package com.react_java.reactjava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactjavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
